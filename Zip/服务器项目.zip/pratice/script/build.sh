#!/bin/bash
# ***********************************************************************
# Copyright: (c) Huawei Technologies Co., Ltd. 2019. All rights reserved.
# script for build
# version: 1.0.0
# change log:
# ***********************************************************************
set -ex
set -o pipefail

cd $codeRootDir

# change configuration
dateStr=`date "+%Y%m%d%H%M%S"`
sed -i "s/\.timestamp/\.$dateStr/g" ./script/deploy/package.json
sed -i "s/\.timestamp/\.$dateStr/g" ./build/webpack.base.conf.js

# download dependence
npm install

# build   开发环境就是build，生产环境是build_prod
npm run build

# cp ./script/deploy/package.json ./clouddragon/

# bash ${WORKSPACE}/Script/clouddragon/build2.0/service/getPackageInfo.sh "$codeRootDir/clouddragon" "web-server-console_*.zip" "" "" ""