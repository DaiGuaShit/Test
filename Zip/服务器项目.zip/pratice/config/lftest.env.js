"use strict";
module.exports = {
  NODE_ENV: '"lftest"',
  ENV_CONFIG: '"lftest"',
  API_ROOT: '""',
  API_URL: '"/copyrightservice"'
};
