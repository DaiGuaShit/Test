"use strict";
module.exports = {
  NODE_ENV: '"predev"',
  ENV_CONFIG: '"predev"',
  API_ROOT: '""',
  API_URL: '"/copyrightservice"'
};
