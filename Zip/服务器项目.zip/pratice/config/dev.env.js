"use strict";
module.exports = {
  NODE_ENV: '"development"',
  ENV_CONFIG: '"dev"',
  API_ROOT: '""',
  API_URL: '"/copyrightservice"'
};
