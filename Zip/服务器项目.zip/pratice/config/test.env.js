"use strict";
module.exports = {
  NODE_ENV: '"testing"',
  ENV_CONFIG: '"test"',
  API_ROOT: '""',
  API_URL: '"/copyrightservicetest"'
};
