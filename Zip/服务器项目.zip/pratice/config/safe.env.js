"use strict";
module.exports = {
  NODE_ENV: '"safe"',
  ENV_CONFIG: '"safe"',
  API_ROOT: '""',
  API_URL: '"/copyrightservice"'
};
