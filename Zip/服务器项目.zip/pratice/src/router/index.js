import Vue from "vue";
import VueRouter from "vue-router";

import environmentList from "../pages/environmentList";
import serverList from "../pages/serverList";
import dataBoard from "../pages/dataBoard";
import home from "../pages/home";

Vue.use(VueRouter);

let originPush = VueRouter.prototype.push;
VueRouter.prototype.push = function(location, resolve, reject) {
  if (resolve && reject) {
    // this：VueRouter一个实例
    originPush.call(this, location, resolve, reject);
  } else {
    originPush.call(
      this,
      location,
      () => {},
      () => {}
    );
  }
};

export default new VueRouter({
  routes: [
    {
      path: "/",
      name: "home",
      component: home
    },
    {
      path: "/environmentList",
      name: "environmentList",
      component: environmentList
    },
    {
      path: "/serverList",
      name: "serverList",
      component: serverList,
      props: $route => ({ envInfo: $route.params.envInfo })
    },
    {
      path: "/dataBoard",
      name: "dataBoard",
      component: dataBoard
    }
  ]
});
