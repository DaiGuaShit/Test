<template>
  <div id="app">
    <el-container>
      <el-header height="50px">
        <Header></Header>
      </el-header>
      <el-container class="main">
        <el-aside width="48px">
          <Aside></Aside>
        </el-aside>
        <el-main>
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
export default {
  name: "App",
};
</script>

<style lang="less" scoped>
#app {
  height: 100%;

  > .el-container {
    // border: 1px solid red;
    height: 100%;

    .el-header {
      background-color: #282b33;
      padding: 0;
    }

    .main {
      // border: 1px solid red;
      height: 100%;
      position: relative;

      .el-aside {
        // border: 1px solid red;
        height: 100%;
      }

      .el-main {
        // border: 1px solid red;
        left: 48px;
        right: 0;
        background-color: #eef0f5;
        height: 100%;
        position: absolute;
      }
    }
  }
}
</style>