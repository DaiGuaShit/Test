import Vue from "vue";
import Vuex from "vuex";

import environment from "./environment.js";
import serverList from "./serverList.js";

Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    environment,
    serverList
  }
});
