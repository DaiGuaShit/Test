import { reqServerList } from "../api/serverList.js";

const state = {
  serverList: []
};

const mutations = {
  GETSERVERLIST(state, serverList) {
    state.serverList = serverList;
  }
};

const actions = {
  async getServerList({ commit }) {
    let result = await reqServerList();
    if (result.code == 200) {
      commit("GETSERVERLIST", result.data);
    }
  }
};

const getters = {};

export default {
  // namespace: true,
  state,
  mutations,
  actions,
  getters
};
