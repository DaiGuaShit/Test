import { reqEnvironmentTree } from "../api/environment.js";

const state = {
  environmentTree: []
};

const mutations = {
  GETENVIRONMENTTREE(state, environmentTree) {
    state.environmentTree = environmentTree;
  }
};

const actions = {
  async getEnvironmentTree({ commit }) {
    let result = await reqEnvironmentTree();
    if (result.code == 200) {
      commit("GETENVIRONMENTTREE", result.data);
    }
  }
};

const getters = {};

export default {
  // namespace: true,
  state,
  mutations,
  actions,
  getters
};
