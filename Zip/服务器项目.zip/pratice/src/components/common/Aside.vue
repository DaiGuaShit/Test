<template>
  <div id="aside">
    <div class="container">
      <ul>
        <li>
          <i class="iconfont icon-list"></i>
          <span>服务器列表</span>
        </li>
        <div class="split"></div>
        <li @click="changePath('/environmentList')">
          <i class="hwsicon hwsicon-frame-service-rds"></i>
          <span>环境列表</span>
        </li>
        <li @click="changePath('/serverList')">
          <i class="hwsicon hwsicon-frame-service-ecm"></i>
          <span>服务器列表</span>
        </li>
        <li @click="changePath('/dataBoard')">
          <i class="hwsicon hwsicon-frame-service-ess"></i>
          <span>数据看板</span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: "Aside",
  methods: {
    // 切换路由
    changePath(path) {
      this.$router.push(`${path}`);
    },
  },
};
</script>

<style lang="less" scoped>
#aside {
  // border: 1px solid red;
  height: 100%;
  background-color: #fff;
  border-right: 1px solid #dfe1e6;

  .container {
    // border: 1px solid red;
    position: absolute;
    background-color: #fff;
    height: 100%;
    width: 48px;
    border-right: 1px solid #dfe1e6;
    overflow: hidden;
    z-index: 100;
    // display: none;

    .iconfont {
      display: block;
      font-size: 24px;
      margin: 12px 12px;
    }

    .hwsicon {
      display: block;
      font-size: 20px;
      margin: 14px 14px;
    }

    .split {
      // height: 14px;
      border-bottom: 1px solid #dfe1e6;
      margin: 0 6px;
    }

    ul > li {
      // border: 1px solid red;
      display: flex;
      width: 240px;
      height: 46px;
      cursor: pointer;

      span {
        // border: 1px solid red;
        line-height: 48px;
      }
    }

    ul > li:hover {
      color: #5c76cf;
      background-color: #f5f6f7;
    }
  }

  .container:hover {
    width: 240px;
    transition: all 0.2s;
  }
}
</style>