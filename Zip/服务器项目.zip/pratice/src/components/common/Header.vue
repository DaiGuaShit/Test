<template>
  <div id="header">
    <div class="left_header">
      <router-link to="/"
        ><img class="logo" src="../../assets/logo/huawei.png"
      /></router-link>
      <div class="title" @click="changePath('/')">DCI服务器控制台</div>
      <div class="split"></div>
      <div class="list">
        <span @click="changePath('/environmentList')">环境列表</span>
        <span @click="changePath('/serverList')">服务器列表</span>
        <span @click="changePath('/dataBoard')">数据看板</span>
      </div>
    </div>
    <div class="right_header">
      <div class="language">中文（简体）</div>
      <div class="user">Admin</div>
      <div class="split"></div>
      <div class="cloudshell">
        <svg data-v-1454fb9f="" width="16" height="16" viewBox="0 0 16 16">
          <path
            data-v-1454fb9f=""
            d="M15,1.5 C15.5522847,1.5 16,1.94771525 16,2.5 L16,13.5 C16,14.0522847 15.5522847,14.5 15,14.5 L1,14.5 C0.44771525,14.5 6.76353751e-17,14.0522847 0,13.5 L0,2.5 C-6.76353751e-17,1.94771525 0.44771525,1.5 1,1.5 L15,1.5 Z M14.5,3 L1.5,3 L1.5,13 L14.5,13 L14.5,3 Z M12.002493,9.25 C12.4167066,9.25 12.752493,9.58578644 12.752493,10 C12.752493,10.3796958 12.4703391,10.693491 12.1042636,10.7431534 L12.002493,10.75 L9,10.75 C8.58578644,10.75 8.25,10.4142136 8.25,10 C8.25,9.62030423 8.53215388,9.30650904 8.89822944,9.25684662 L9,9.25 L12.002493,9.25 Z M4.44774462,5.14724021 L4.53197086,5.21995143 L6.65600971,7.34399029 C6.9226175,7.61059807 6.94685458,8.02779572 6.72872093,8.32178348 L6.65600971,8.40600971 L4.53197086,10.5300486 C4.23870229,10.8233171 3.76321999,10.8233171 3.46995143,10.5300486 C3.20334364,10.2634408 3.17910657,9.84624314 3.39724021,9.55225538 L3.46995143,9.46802914 L5.06231955,7.87467925 L3.46995143,6.28197086 C3.20334364,6.01536307 3.17910657,5.59816542 3.39724021,5.30417766 L3.46995143,5.21995143 C3.73655921,4.95334364 4.15375686,4.92910657 4.44774462,5.14724021 Z"
            id="icon-消息"
          ></path>
        </svg>
      </div>
      <div class="message_box">
        <svg data-v-1454fb9f="" width="16" height="14" viewBox="0 0 16 14">
          <path
            data-v-1454fb9f=""
            d="M14 2.494L8.778 7.277a1.574 1.574 0 0 1-2.145.001L1.4 2.493V11H14V2.494zM12.983 1.4H2.418l5.168 4.725c.068.063.17.063.238 0L12.983 1.4zM1.2 0h13a1.2 1.2 0 0 1 1.2 1.2v10a1.2 1.2 0 0 1-1.2 1.2h-13A1.2 1.2 0 0 1 0 11.2v-10A1.2 1.2 0 0 1 1.2 0z"
            fill-rule="nonzero"
          ></path>
        </svg>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Header",
  methods: {
    // 切换路由
    changePath(path) {
      this.$router.push(`${path}`);
    },
  },
};
</script>

<style lang="less" scoped>
#header {
  // border: 1px solid red;
  height: 100%;
  display: flex;
  justify-content: space-between;
  line-height: 50px;

  .left_header {
    // border: 1px solid red;
    display: flex;
    margin-left: 5px;
    font-size: 16px;

    .logo {
      cursor: pointer;
    }

    .title {
      color: #fff;
      margin-left: 8px;
      cursor: pointer;
    }

    .split {
      height: 14px;
      border-left: 1px solid #53555c;
      margin: 18px 20px;
    }

    .list {
      color: #adb0b8;
      font-size: 12px;

      span {
        margin-right: 12px;
        cursor: pointer;
      }

      span:hover {
        color: #fff;
      }
    }
  }

  .right_header {
    // border: 1px solid red;
    display: flex;
    margin-right: 10px;
    color: #adb0b8;
    font-size: 12px;

    .language {
      padding: 0 16px;
      cursor: pointer;
    }

    .language:hover {
      color: #fff;
      background-color: #181818;
    }

    .user {
      padding: 0 16px;
      cursor: pointer;
    }
    .user:hover {
      color: #fff;
      background-color: #181818;
    }

    .split {
      height: 14px;
      border-left: 1px solid #53555c;
      margin: 18px 10px;
    }

    .cloudshell {
      padding: 3px 16px;
      fill: #adb0b8;
      cursor: pointer;
    }

    .cloudshell:hover {
      fill: #7693f5;
      background-color: #181818;
    }

    .message_box {
      padding: 3px 16px;
      fill: #adb0b8;
      cursor: pointer;
    }

    .message_box:hover {
      fill: #7693f5;
      background-color: #181818;
    }
  }
}
</style>