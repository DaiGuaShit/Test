<template>
  <div>
    <div id="treeChart">
      <div class="header">
        <div class="title">
          <div class="titleBody" @click="clickEnv([])">
            <div class="text">DCI服务控制台</div>
            <div class="text">DCI Service Console</div>
          </div>
          <div class="dci">
            <div class="line"></div>
            <div class="dciBody" @click="clickEnv([0])">
              <div class="text">DCI</div>
            </div>
          </div>
        </div>
      </div>
      <div v-show="environmentTree.length != 0" class="treeLine">
        <div class="line1"></div>
        <div class="line2"></div>
        <div class="leftBlock block"></div>
        <div class="rightBlock block"></div>
      </div>
      <div class="treeMian">
        <div class="treeTrunk" v-for="env1 in environmentTree" :key="env1.id">
          <div class="env1">
            <div class="line1"></div>
            <div class="env1Body">
              <div
                v-show="isUpdate"
                class="left iconfont icon-leftarrow"
                @click="orderEnv({ id: env1.id, flag: 'up' })"
              ></div>
              <div
                class="text"
                @click="
                  clickEnv({
                    id: env1.id,
                    envName: env1.envName,
                    topId: env1.topId,
                    orderid: env1.orderid,
                  })
                "
              >
                {{ env1.envName }}
              </div>
              <div
                v-show="isUpdate"
                class="right iconfont icon-Rightarrow"
                @click="orderEnv({ id: env1.id, flag: 'down' })"
              ></div>
            </div>
            <!-- 编辑模式打开，或者子元素不为空的时候展示 -->
            <div
              v-show="isUpdate || env1.children.length != 0"
              class="line2"
            ></div>
          </div>
          <div class="env2" v-for="env2 in env1.children" :key="env2.id">
            <div class="line"></div>
            <div class="env2Body">
              <div
                class="text"
                @click="
                  clickEnv({
                    id: env1.id,
                    envName: env1.envName,
                    topId: env1.topId,
                    childId: env2.id,
                    childEnvName: env2.envName,
                    childTopId: env2.topId,
                    orderid: env2.orderid,
                  })
                "
              >
                {{ env2.envName }}
              </div>
              <div
                v-show="isUpdate"
                class="up iconfont icon-up"
                @click="orderEnv({ id: env2.id, flag: 'up' })"
              ></div>
              <div
                v-show="isUpdate"
                class="down iconfont icon-down"
                @click="orderEnv({ id: env2.id, flag: 'down' })"
              ></div>
            </div>
          </div>
          <div v-show="isUpdate" class="update">
            <div class="line"></div>
            <div
              class="addButton"
              @click="
                addEnv({ topId: env1.id, orderid: env1.children.length + 1 })
              "
            >
              <span>+</span>
            </div>
          </div>
        </div>
      </div>
      <div v-show="isUpdate" class="addTreeTrunk">
        <div class="lineTop"></div>
        <div class="lineLeft"></div>
        <div
          class="addButton"
          @click="addEnv({ topId: '0', orderid: environmentTree.length + 1 })"
        >
          <span>+</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TreeChart",
  props: {
    // 控制编辑模式是否打开
    isUpdate: Boolean,
    // 环境树
    environmentTree: Array,
    // 父组件进行处理环境信息的方法
    handleEnvInfo: Function,
    // 排序的方法
    orderEnvInfo: Function,
  },
  data() {
    return {
      envInfo: [],
    };
  },
  methods: {
    // 点击环境时的回调
    clickEnv(envInfo) {
      // 如果编辑模式未打开 路由跳转 通知服务器列表组件更新查询条件 筛选出对应服务器数据
      if (!this.isUpdate) {
        // 判断是不是数组 是数组直接跳转
        if (envInfo instanceof Array == true) {
          this.$router.push({
            name: "serverList",
            params: { envInfo: envInfo },
          });
          // 将环境信息绑定到$bus上 服务器列表组件获取
          // this.$bus.envInfo = envInfo;
        }
        // 不是数组 将其处理成数组
        else {
          // 一级数组
          if (!envInfo.childId) {
            this.envInfo.push(envInfo.id);
          }
          // 二级数组
          else {
            this.envInfo.push(envInfo.id, envInfo.childId);
          }
          this.$router.push({
            name: "serverList",
            params: { envInfo: this.envInfo },
          });
        }
      }
      // 如果编辑模式打开 进入编辑dialog
      else {
        // 将对应的环境信息传递给父组件进行处理
        this.handleEnvInfo(envInfo);
      }
    },

    // 添加环境时的回调
    addEnv(envInfo) {
      this.handleEnvInfo(envInfo);
    },

    // 排序的回调
    orderEnv(envInfo) {
      this.orderEnvInfo(envInfo);
    },
  },
};
</script>

<style lang="less" scoped>
#treeChart {
  //   border: 1px solid black;
  color: white;
  text-align: center;
  margin: auto 0;
  font-size: 14px;
  display: inline-block;
  position: relative;

  //   添加按钮统一样式
  .addButton {
    width: 56px;
    height: 60px;
    background: #f4f4f4;
    color: #d1d3d5;
    font-size: 30px;
    text-align: center;
    line-height: 60px;
    margin: 0 auto;
    cursor: pointer;
  }

  // 给文字统一设置水平/垂直居中
  .text {
    // border: 1px solid red;
    width: 150px;
    margin: 0 auto;
  }
  .header {
    // 头部
    .title {
      //   border: 1px solid red;
      width: 216px;
      height: 76px;
      background-color: #4bb0b9;
      border-radius: 5px;
      margin: 0 auto;
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;

      .dci {
        display: flex;
        position: absolute;
        top: 8px;
        left: 216px;
        .line {
          background-color: #afd6d7;
          width: 18px;
          height: 2px;
          margin: auto 0;
        }
        .dciBody {
          width: 176px;
          height: 60px;
          background-color: #f0909b;
          border-radius: 5px;
          display: flex;
          align-items: center;
          cursor: pointer;
        }
      }
    }
  }
  // 链接头部和树干的线条
  .treeLine {
    //   border: 1px solid red;
    position: relative;

    .line1 {
      background-color: #afd6d7;
      width: 2px;
      height: 16px;
      margin: 0 auto;
    }
    .line2 {
      background-color: #afd6d7;
      width: 100%;
      height: 2px;
      margin: 0 auto;
    }
    .block {
      height: 2px;
      width: 89px;
      background-color: white;
      position: absolute;
      top: 16px;
    }
    .leftBlock {
      left: 0px;
    }
    .rightBlock {
      right: 0px;
    }
  }
  // 树干
  .treeMian {
    // border: 1px solid red;
    display: inline-block;
    display: flex;
    justify-content: space-around;

    .treeTrunk {
      //   border: 1px solid red;
      margin: 0 2px;

      .env1 {
        .line1 {
          background-color: #afd6d7;
          width: 2px;
          height: 16px;
          margin: 0 auto;
        }
        .env1Body {
          // border: 1px solid black;
          width: 176px;
          height: 60px;
          background-color: #f0909b;
          border-radius: 5px;
          display: flex;
          align-items: center;
          cursor: pointer;

          .iconfont {
            // border: 1px solid black;
            font-size: 20px;
            display: none;
          }
        }

        .env1Body:hover .iconfont {
          display: block;
        }

        .line2 {
          background-color: #afd6d7;
          width: 2px;
          height: 20px;
          margin: 0 auto;
        }
      }
      .env2 {
        .line {
          background-color: #afd6d7;
          width: 2px;
          height: 16px;
          margin: 0 auto;
        }
        .env2Body {
          // border: 1px solid black;
          width: 176px;
          height: 60px;
          background-color: #4bb0b9;
          border-radius: 5px;
          display: flex;
          align-items: center;
          position: relative;
          cursor: pointer;

          .iconfont {
            position: absolute;
            left: 160px;
            font-size: 14px;
            display: none;
          }
          .up {
            top: 10px;
          }
          .down {
            bottom: 10px;
          }
        }

        .env2Body:hover .iconfont {
          display: block;
        }
      }
      .update {
        .line {
          background-color: #afd6d7;
          width: 2px;
          height: 16px;
          margin: 0 auto;
        }
      }
    }
  }
  //   添加一级环境按钮
  .addTreeTrunk {
    // border: 1px solid black;
    display: inline-block;
    position: absolute;
    right: -58px;
    top: 94px;

    .lineTop {
      background-color: #afd6d7;
      width: 2px;
      height: 16px;
      margin: 0 auto;
    }

    .lineLeft {
      background-color: #afd6d7;
      width: 120px;
      height: 2px;
      position: absolute;
      left: -91px;
      top: -2px;
    }
  }
}
</style>