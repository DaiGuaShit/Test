import requests from "../utils/request";

// 获得环境列表（Tree）
// GET	http://127.0.0.1:9999/v1/EnvironmentTree
export const reqEnvironmentTree = () =>
  requests({
    url: "/EnvironmentTree",
    method: "GET"
  });

// 获得环境列表
// GET	http://127.0.0.1:9999/v1/EnvironmentList

// 获得环境
// GET	http://127.0.0.1:9999/v1/Environment/{id}
export const reqGetEnvironmentInfo = id =>
  requests({
    url: `/Environment/${id}`,
    method: "GET"
  });

// 添加环境
// POST	http://127.0.0.1:9999/v1/Environment
// {
//     "envName": "开发环境1221",
//     "topId": 1,
//     "orderid": 1,
//     "status": 1
// }

// 修改环境
// PUT	http://127.0.0.1:9999/v1/Environment
// {
//     "id": "26",
//     "envName": "开发环境121",
//     "topId": 0,
//     "orderid": 1,
//     "status": 1
// }
export const reqUpdateEnvironmentInfo = data =>
  requests({
    url: "Environment",
    method: data ? "PUT" : "POST",
    data
  });

// 删除环境
// DELETE	http://127.0.0.1:9999/v1/Environment/{id}
export const reqDeleteEnvironmentInfo = id =>
  requests({
    url: `/Environment/${id}`,
    method: "DELETE"
  });

// 修改环境排序
// GET	http://127.0.0.1:9999/v1/Environment/{id}/{done}
// done可选参数：up、down
export const reqOrderEnvironment = (id, flag) =>
  requests({
    url: `/Environment/${id}/${flag}`,
    method: "GET"
  });
