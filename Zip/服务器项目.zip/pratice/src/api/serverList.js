import requests from "../utils/request";

// 获得服务器列表
// GET	http://127.0.0.1:8001/v1/ServerList
export const reqServerList = () =>
  requests({ url: "/ServerList", method: "GET" });

// 获得服务器
// GET	http://127.0.0.1:8001/v1/ServerEntity/1

// 添加服务器
// POST	http://127.0.0.1:8001/v1/ServerEntity

// 修改服务器
// PUT	http://127.0.0.1:8001/v1/ServerEntity
export const reqAddOrUpdateServerInfo = data =>
  requests({
    url: "/ServerEntity",
    method: data.id ? "PUT" : "POST",
    data
  });
