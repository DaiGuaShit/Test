import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";

import ElementUI from "element-ui";
import "element-ui/lib/theme-chalk/index.css";
Vue.use(ElementUI);

import "./assets/iconfont/iconfont-huawei.css";
import "./assets/iconfont-ali/iconfont.css";
import "./assets/css/global.less";

Vue.config.productionTip = false;

import Aside from "./components/common/Aside";
import Header from "./components/common/Header";
import TreeChart from "./components/TreeChart";

Vue.component(Aside.name, Aside);
Vue.component(Header.name, Header);
Vue.component(TreeChart.name, TreeChart);

export default new Vue({
  beforeCreate() {
    Vue.prototype.$bus = this;
  },
  el: "#app",
  render: h => h(App),
  router,
  store
});
