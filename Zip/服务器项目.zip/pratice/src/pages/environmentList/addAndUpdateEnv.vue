<template>
  <div id="addAndUpdateEnv">
    <el-dialog
      :title="form.id ? '修改环境' : '新增环境'"
      :visible.sync="dialogFormVisible"
      :before-close="closeDialog"
      width="700px"
    >
      <el-form :model="form" size="mini" ref="form" :rules="rules">
        <!-- 修改时展示 即form不为空对象 -->
        <el-form-item v-show="form.id" label="Id" label-width="100px">
          <el-input v-model="form.id" disabled></el-input>
        </el-form-item>
        <!-- 添加时展示 即form为空对象 -->
        <el-form-item v-show="!form.id" label="TopId" label-width="100px">
          <el-input v-model="form.topId" disabled></el-input>
        </el-form-item>
        <el-form-item label="环境名称" label-width="100px" prop="envName">
          <el-input v-model="form.envName"></el-input>
        </el-form-item>
        <el-form-item label-width="100px">
          <!-- 点击添加按钮 展示立即新增 删除按钮不展示 
               点击某个环境 展示立即修改 环境下没有子环境/服务器实例 展示删除按钮
                                       环境下有子环境/服务器实例 展示删除按钮-->
          <el-button type="primary" @click="submitForm()">{{
            form.id ? "立即修改" : "立即新增"
          }}</el-button>
          <el-button
            v-show="form.id && form.isDelete"
            type="danger"
            @click="deleteEnv()"
            >删除</el-button
          >
          <el-button v-show="form.id && !form.isDelete" type="danger" plain
            >无法删除</el-button
          >
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import {
  reqUpdateEnvironmentInfo,
  reqDeleteEnvironmentInfo,
} from "../../api/environment";
export default {
  name: "AddAndUpdateEnv",
  props: {
    dialogFormVisible: Boolean,
    closeDialogForm: Function,
    envInfoForm: Object,
  },
  data() {
    var validateEnvName = (rule, value, callback) => {
      if (!value.trim()) {
        return callback(new Error("环境名称不能为空 请输入正确的值"));
      } else {
        callback();
      }
    };
    return {
      // 一级环境 topId==0
      form: this.envInfoForm ? this.envInfoForm : {},
      rules: {
        envName: [
          { required: true, message: "请填写环境名称", trigger: "blur" },
          { validator: validateEnvName, trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    //   通知父组件关闭新增修改对话框
    closeDialog() {
      this.closeDialogForm();
      this.$refs["form"].resetFields();
    },

    // 修改新增的回调
    submitForm() {
      this.$refs["form"].validate((valid) => {
        if (valid) {
          this.addOrUpdateEnv();
        } else {
          this.$message({
            message: "提交失败 请检查环境名称填写是否正确",
            showClose: true,
            type: "error",
          });
          return false;
        }
      });
    },

    // 发送增加/修改的ajax请求
    async addOrUpdateEnv() {
      let { envName, id, topId, orderid } = this.form;
      let envInfo = {
        id: id,
        envName: envName,
        topId: topId,
        orderid: orderid,
        status: 1,
      };
      let result = await reqUpdateEnvironmentInfo(envInfo);
      if (result.code == 200) {
        this.$message({
          message: envInfo.id ? "修改成功" : "新增成功",
          showClose: true,
          type: "success",
        });
        // 关闭对话框
        this.closeDialog();
      }
    },

    // 删除的回调
    async deleteEnv() {
      let result = await reqDeleteEnvironmentInfo(this.form.id);
      // console.log(result);

      if (result.code == 200) {
        this.$message({
          message: "删除成功",
          showClose: true,
          type: "success",
        });
        // 关闭对话框
        this.closeDialog();
      }
    },
  },
};
</script>

<style scoped>
</style>