<template>
  <div id="environment">
    <span class="title">环境列表</span>
    <el-popover
      popper-class="base-header-popper"
      trigger="hover"
      width="360"
      placement="right-start"
      content="DCI服务器控制台是可以方便组员快速查看服务器配置状态的小工具，通过环境列表，可以快速查看服务器环境进行配置操作。"
    >
      <el-icon slot="reference" class="hwsicon icon-cloud-action-tip"></el-icon>
    </el-popover>
    <el-card style="margin-top: 20px">
      <el-switch
        v-model="isUpdate"
        active-color="#13ce66"
        inactive-color="rgb(244, 244, 244)"
      >
      </el-switch>
      <TreeChart
        style="margin: 20px 0"
        :isUpdate="isUpdate"
        :environmentTree="environmentTree"
        :handleEnvInfo="handleEnvInfo"
        :orderEnvInfo="orderEnvInfo"
      />
      <AddAndUpdateEnv
        :dialogFormVisible="dialogFormVisible"
        :closeDialogForm="closeDialogForm"
        :envInfoForm="envInfoForm"
        :environmentTree="environmentTree"
      />
    </el-card>
  </div>
</template>

<script>
import { mapState } from "vuex";
import AddAndUpdateEnv from "./addAndUpdateEnv.vue";
import {
  reqGetEnvironmentInfo,
  reqOrderEnvironment,
} from "../../api/environment";

export default {
  name: "Environment",
  components: {
    AddAndUpdateEnv,
  },
  data() {
    return {
      // 控制子组件是否可编辑 最后改成false
      isUpdate: false,
      // 控制新增修改dialog是否展示
      dialogFormVisible: false,
      // 传给dialog组件的form表单数据
      envInfoForm: {
        topId: "",
        id: "",
        envName: "",
        isDelete: false,
        orderid: "",
      },
    };
  },
  computed: {
    ...mapState({
      // 环境列表
      environmentTree: (state) => state.environment.environmentTree,
    }),
  },
  mounted() {
    this.$store.dispatch("getEnvironmentTree");
  },
  methods: {
    // 关闭新增修改对话框
    closeDialogForm() {
      this.dialogFormVisible = false;
      this.$store.dispatch("getEnvironmentTree");
    },
    // 打开新增修改对话框
    openDialogForm() {
      this.dialogFormVisible = true;
    },
    // 处理环境树传过来的环境信息
    handleEnvInfo(envInfo) {
      // 将环境信息处理成对象 传给dialog
      // 当envInfo不是头部的环境信息时 再做处理
      if (envInfo instanceof Array == false) {
        this.openDialogForm();
        // console.log(envInfo);
        // 一级环境
        if (!envInfo.childId) {
          this.envInfoForm.topId = envInfo.topId || "";
          this.envInfoForm.id = envInfo.id || "";
          this.envInfoForm.envName = envInfo.envName || "";
          this.envInfoForm.orderid = envInfo.orderid || "";
          // this.isEnv1Delete(envInfo);
          this.isDelete(envInfo.id || "");
        }
        // 二级环境
        else {
          this.envInfoForm.topId = envInfo.childTopId;
          this.envInfoForm.id = envInfo.childId;
          this.envInfoForm.envName = envInfo.childEnvName;
          this.envInfoForm.orderid = envInfo.orderid;
          // this.isEnv2Delete(envInfo);
          this.isDelete(envInfo.childId || "");
        }
      }
    },
    // 根据id获取环境信息 判断是否可以删除
    async isDelete(id) {
      if (id) {
        let result = await reqGetEnvironmentInfo(id);
        // console.log(result.data);
        let environmentInfo = result.data;
        if (
          !environmentInfo.hasServer &&
          (!environmentInfo.children || environmentInfo.children.length == 0)
        ) {
          this.envInfoForm.isDelete = true;
        } else {
          this.envInfoForm.isDelete = false;
        }
      } else {
        return;
      }
    },
    // 排序
    async orderEnvInfo(envInfo) {
      let result = await reqOrderEnvironment(envInfo.id, envInfo.flag);
      if (result.code == 200) {
        this.$store.dispatch("getEnvironmentTree");
      }
    },
  },
};
</script>

<style>
</style>

<style lang="less" scoped>
#environment {
  // border: 1px solid red;

  .title {
    // border: 1px solid red;
    color: #252b3a;
    font-size: 16px;
    font-weight: 700;
    margin-right: 10px;
  }

  .hwsicon {
    // border: 1px solid red;
    font-size: 16px;
  }
}
</style>