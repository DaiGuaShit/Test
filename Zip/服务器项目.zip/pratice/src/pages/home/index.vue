<template>
  <div id="home">
    <el-card class="card">
      <img src="../../assets/logo/dci.png" />
      <span>DCI服务器控制台</span>
    </el-card>
  </div>
</template>

<script>
export default {
  name: "Home",
};
</script>

<style lang="less" scoped>
#home {
  height: 100%;

  .card {
    background-color: #2d3a4b;
    height: 100%;
    display: flex;
    flex-direction: column;
    // justify-content: center;
    align-items: center;

    img {
      display: block;
      margin: 0 auto;
      margin-top: 160px;
    }

    span {
      display: block;
      font-size: 26px;
      color: #eee;
      font-weight: bold;
      margin-top: 40px;
    }
  }
}
</style>