<template>
  <div id="serverList">
    <span class="title">服务器列表</span>
    <el-popover
      popper-class="base-header-popper"
      trigger="hover"
      width="360"
      placement="right-start"
      content="DCI服务器控制台是可以方便组员快速查看服务器配置状态的小工具，通过服务器列表，可以快速筛选服务器进行配置操作。"
    >
      <el-icon slot="reference" class="hwsicon icon-cloud-action-tip"></el-icon>
    </el-popover>
    <el-card style="margin-top: 20px">
      <div class="operation">
        <div class="left">
          <el-tooltip content="新增一台服务器实例信息" placement="top">
            <button @click="addAndUpdateServer({})">新增服务器实例</button>
          </el-tooltip>
          <el-tooltip content="请选择一台或多台要开机的服务器" placement="top">
            <button>开机</button>
          </el-tooltip>
          <el-tooltip content="请选择一台或多台要关机的服务器" placement="top">
            <button>关机</button>
          </el-tooltip>
          <el-tooltip
            content="请选择一台或多台要重置密码的服务器"
            placement="top"
          >
            <button>重置密码</button>
          </el-tooltip>
          <button>更多</button>
        </div>
        <div class="right">
          <el-tooltip content="刷新" placement="top">
            <button>
              <svg
                data-v-16f35655=""
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 32 32"
              >
                <path
                  data-v-16f35655=""
                  d="M23.059 8.878c-1.4-1.4-3.2-2.2-5-2.6-5.4-1-10.4 2.6-11.4 8s2.6 10.4 8 11.4c4.6 0.8 9.2-1.8 11-6.2 0.2-0.8 1-1 1.8-0.8s1 1 0.8 1.8c-2.2 5.6-8 9-14 7.8-7-0.8-11.6-7.4-10.4-14.4s7.8-11.4 14.6-10.2c2.4 0.4 4.6 1.6 6.4 3.2v-1c0-0.8 0.8-1.4 1.6-1.2 1 0 1.4 0.6 1.4 1.4l-0.4 4.4c0 0.8-0.6 1.2-1.4 1.2h-4c-0.8 0-1.4-0.6-1.4-1.4s0.6-1.4 1.4-1.4h1z"
                ></path>
              </svg>
            </button>
          </el-tooltip>
          <el-tooltip content="导出服务器列表" placement="top">
            <button>
              <svg
                data-v-16f35655=""
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 32 32"
              >
                <path
                  data-v-16f35655=""
                  d="M26.4 16c0-0.8 0.6-1.6 1.6-1.6s1.6 0.6 1.6 1.6v10c0 2-1.6 3.6-3.6 3.6h-20c-2 0-3.6-1.6-3.6-3.6v-20c0-2 1.6-3.6 3.6-3.6h10c0.8 0 1.6 0.6 1.6 1.6s-0.8 1.6-1.6 1.6h-10c-0.2 0-0.4 0.2-0.4 0.4v20c0 0.2 0.2 0.4 0.4 0.4h20c0.2 0 0.4-0.2 0.4-0.4v-10zM24.4 5.6l-3-3h7c0.6 0 1 0.4 1 1v7l-3-3-3.6 3.6c-0.6 0.6-1.6 0.6-2.2 0s-0.6-1.6 0-2.2l3.8-3.4z"
                ></path>
              </svg>
            </button>
          </el-tooltip>
          <div class="split"></div>
          <el-tooltip content="精简视图" placement="top">
            <button>
              <svg
                data-v-16f35655=""
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 32 32"
              >
                <path
                  data-v-16f35655=""
                  d="M10 2h-6c-1.2 0-2 0.8-2 2v6c0 2.2 1.8 4 4 4h6c1.2 0 2-0.8 2-2v-6c0-2.2-1.8-4-4-4zM11 11h-5c-0.6 0-1-0.4-1-1v-5h5c0.6 0 1 0.4 1 1v5zM28 2h-6c-2.2 0-4 1.8-4 4v6c0 1.2 0.8 2 2 2h6c2.2 0 4-1.8 4-4v-6c0-1.2-0.8-2-2-2zM27 10c0 0.6-0.4 1-1 1h-5v-5c0-0.6 0.4-1 1-1h5v5zM12 18h-6c-2.2 0-4 1.8-4 4v6c0 1.2 0.8 2 2 2h6c2.2 0 4-1.8 4-4v-6c0-1.2-0.8-2-2-2zM11 26c0 0.6-0.4 1-1 1h-5v-5c0-0.6 0.4-1 1-1h5v5zM26 18h-6c-1.2 0-2 0.8-2 2v6c0 2.2 1.8 4 4 4h6c1.2 0 2-0.8 2-2v-6c0-2.2-1.8-4-4-4zM27 27h-5c-0.6 0-1-0.4-1-1v-5h5c0.6 0 1 0.4 1 1v5z"
                ></path>
              </svg>
            </button>
          </el-tooltip>
          <el-tooltip content="列表视图" placement="top">
            <button>
              <svg
                data-v-16f35655=""
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 32 32"
              >
                <path
                  data-v-16f35655=""
                  d="M5.6 24.8h20.8c0.8 0 1.6 0.8 1.6 1.6s-0.8 1.6-1.6 1.6h-20.8c-0.8 0-1.6-0.8-1.6-1.6s0.8-1.6 1.6-1.6zM5.6 14.4h20.8c0.8 0 1.6 0.8 1.6 1.6s-0.8 1.6-1.6 1.6h-20.8c-0.8 0-1.6-0.8-1.6-1.6s0.8-1.6 1.6-1.6zM5.6 4h20.8c0.8 0 1.6 0.8 1.6 1.6s-0.8 1.6-1.6 1.6h-20.8c-0.8 0-1.6-0.8-1.6-1.6s0.8-1.6 1.6-1.6z"
                ></path>
              </svg>
            </button>
          </el-tooltip>
        </div>
      </div>
      <div class="query">
        <!-- @change="updateFliterObj" -->
        <el-cascader
          v-model="fliterObj.val0"
          :options="getEnvironmentOptions"
          :props="{ checkStrictly: true }"
          clearable
          placeholder="请选择实例环境类目"
          size="mini"
        ></el-cascader>
        <!-- @change="updateFliterObj" -->
        <el-select
          v-model="fliterObj.val1"
          clearable
          placeholder="请选择实例运行状态"
          size="mini"
        >
          <el-option
            v-for="option in serverStatusOptions"
            :key="option.value"
            :label="option.label"
            :value="option.value"
          >
          </el-option>
        </el-select>
        <!-- @input="updateFliterObj" -->
        <el-input
          placeholder="输入搜索内容（当前支持 ip、标签 模糊搜索）"
          size="mini"
          v-model="fliterObj.val2"
          clearable
        >
          <i slot="suffix" class="el-input__icon el-icon-search"></i>
        </el-input>
      </div>
      <el-table
        :data="fliterServerData"
        style="width: 100%; margin-top: 20px"
        size="mini"
        header-row-class-name="table_header_class"
      >
        <el-table-column type="selection" width="42" align="center">
        </el-table-column>
        <el-table-column label="监控" width="60" align="center"
          ><svg
            data-v-16f35655=""
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 32 32"
            style="
              vertical-align: text-top;
              fill: rgb(82, 110, 204);
              cursor: pointer;
            "
          >
            <path
              data-v-16f35655=""
              d="M2.8 4.7v16.4h26.4v-16.4h-26.4zM2 1.9h28c1.2 0 2 0.8 2 2v18c0 1.2-0.8 2-2 2h-28c-1.2 0-2-0.8-2-2v-18c0-1.2 0.8-2 2-2zM8.6 30.1c-0.8 0-1.4-0.6-1.4-1.4s0.6-1.4 1.4-1.4h15.4c0.8 0 1.4 0.6 1.4 1.4s-0.6 1.4-1.4 1.4h-15.4zM10.6 15.5c-0.2 0.4-0.6 0.6-0.8 0.6h-2.6c-0.6 0-1-0.4-1-1s0.4-1 1-1h2l1.4-2.2c0.4-0.8 1.4-0.6 1.8 0.2l1.4 3.6 3.4-9.4c0.2-0.8 1.4-0.8 1.8-0.2l4 8h1.8c0.6 0 1 0.4 1 1s-0.4 1-1 1h-2.4c-0.4 0-0.8-0.2-0.8-0.6l-3.4-6.4-3.6 9.8c-0.4 0.8-1.6 0.8-1.8 0l-1.6-4.4-0.6 1z"
            ></path>
          </svg>
        </el-table-column>
        <el-table-column label="IP地址" width="120">
          <template slot-scope="{ row }"
            >{{ row.ipAddress
            }}<i
              class="iconfont icon-copy"
              type="text"
              :data-clipboard-text="row.ipAddress"
              id="equSN"
              @click="copy"
          /></template>
        </el-table-column>
        <el-table-column label="账号/密码" type="expand" width="80">
          <template slot-scope="{ row }">
            <el-form
              label-position="left"
              inline
              class="demo-table-expand"
              v-for="(account, index) in row.accountAndPassword"
              :key="index"
            >
              <el-form-item>
                <span>{{ account.name }}</span>
                <span
                  >账号：{{ account.user
                  }}<i
                    class="iconfont icon-copy"
                    type="text"
                    :data-clipboard-text="account.user"
                    id="equSN"
                    @click="copy"
                /></span>
                <span
                  >密码：{{ account.pwd
                  }}<i
                    class="iconfont icon-copy"
                    type="text"
                    :data-clipboard-text="account.pwd"
                    id="equSN"
                    @click="copy"
                /></span>
              </el-form-item>
            </el-form>
          </template>
        </el-table-column>
        <el-table-column label="类目" width="300">
          <template slot-scope="{ row }">
            <span>{{
              row.envInfo.env2Value
                ? row.envInfo.env2Value
                : row.envInfo.env1Value
            }}</span>
          </template>
        </el-table-column>
        <el-table-column label="标签">
          <template slot-scope="{ row }">
            <el-tag
              type="success"
              v-for="(description, index) in row.descriptionLabel"
              :key="index"
              >{{ description }}</el-tag
            >
          </template>
        </el-table-column>
        <el-table-column label="状态" width="180">
          <template slot-scope="{ row }">
            <span v-if="row.status == 1" style="color: green">
              {{ getServerStatus(row.status) }}
            </span>
            <span v-if="row.status == 2" style="color: blue">
              {{ getServerStatus(row.status) }}
            </span>
            <span v-if="row.status == 3" style="color: yellow">
              {{ getServerStatus(row.status) }}
            </span>
            <span v-if="row.status == 0" style="color: grey">
              {{ getServerStatus(row.status) }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180">
          <template slot-scope="{ row }">
            <el-button size="mini">远程登录</el-button>
            <el-button
              type="danger"
              size="mini"
              @click="addAndUpdateServer(row)"
              >修改</el-button
            >
          </template>
        </el-table-column>
      </el-table>
      <AddAndUpdateServer
        :dialogFormVisible="dialogFormVisible"
        :closeDialogForm="closeDialogForm"
        :serverInfo="serverInfo"
        :environmentOptions="getEnvironmentOptions"
      />
    </el-card>
  </div>
</template>

<script>
import { mapState } from "vuex";
import Clipboard from "clipboard";
import AddAndUpdateServer from "./addAndUpdateServer.vue";
export default {
  name: "ServerList",
  components: { AddAndUpdateServer },
  props: ["envInfo"],
  data() {
    return {
      // 实例运行状态选择器类目
      serverStatusOptions: [
        {
          value: 1,
          label: "正在使用",
        },
        {
          value: 2,
          label: "已经释放",
        },
        {
          value: 3,
          label: "未使用",
        },
        {
          value: 0,
          label: "已删除",
        },
      ],
      // 查询条件
      fliterObj: {
        // 写法一：获取$bus上的环境信息
        // val0: this.$bus.envInfo ? [...this.$bus.envInfo] : [],
        // 写法二：路由传参
        // val0: this.$route.params.envInfo ? [...this.$route.params.envInfo] : [],
        // 写法三：props路由传参
        val0: this.envInfo ? [...this.envInfo] : [],
        val1: "",
        val2: "",
      },
      // 控制新增修改dialog是否展示
      dialogFormVisible: false,
      // 传递给子组件的服务器信息
      serverInfo: {},
    };
  },
  mounted() {
    this.$store.dispatch("getServerList");
    this.$store.dispatch("getEnvironmentTree");
  },
  created() {},
  methods: {
    // 判断实例运行状态
    getServerStatus(num) {
      let status = "";
      this.serverStatusOptions.forEach((item) => {
        if (item.value == num) {
          status = item.label;
        }
      });
      return status;
    },

    // 根据环境id判断一级环境/二级环境
    getEnvInfo(envId) {
      let envInfo = {};
      this.getEnvironmentOptions.forEach((item, index) => {
        // 如果环境id是一级环境id
        if (item.value == envId) {
          if (item.value == 0) {
            envInfo = { env1Id: 0, env1Value: "DCI（未分配类目）" };
          } else {
            envInfo = { env1Id: item.value, env1Value: item.label };
          }
        } else {
          item.children.forEach((childrenItem) => {
            if (childrenItem.value == envId) {
              envInfo = {
                env1Id: item.value,
                env1Value: item.label,
                env2Id: childrenItem.value,
                env2Value: `${item.label} / ${childrenItem.label}`,
              };
            }
          });
        }
      });
      return envInfo;
    },

    // 复制
    copy() {
      var clipboard = new Clipboard("#equSN");
      clipboard.on("success", (e) => {
        this.$message.success(`${e.text}已成功复制到粘贴板`);
        //  释放内存
        clipboard.destroy();
      });
      clipboard.on("error", (e) => {
        // 不支持复制
        this.$message.warning("该浏览器不支持复制");
        // 释放内存
        clipboard.destroy();
      });
    },

    // 点击修改服务器实例按钮的回调
    addAndUpdateServer(serverInfo) {
      if (Object.keys(serverInfo).length == 0) {
        this.serverInfo = { envInfo: { env1Id: 0, env1Value: "DCI" } };
      } else {
        // 将对应的服务器信息传递给子组件
        this.serverInfo = serverInfo;
      }
      this.dialogFormVisible = true;
    },

    // 子组件通知父组件关闭对话框dialog
    closeDialogForm() {
      this.dialogFormVisible = false;
      this.$store.dispatch("getServerList");
      this.$store.dispatch("getEnvironmentTree");
    },

    // 环境列表组件传查询条件过来 更新查询条件
    // updateFliterObj(envInfo) {
    //   console.log("start", envInfo);
    //   this.fliterObj.val0.push(...envInfo);
    //   console.log("final", this.fliterObj);
    // },
  },
  computed: {
    ...mapState({
      // 环境列表
      environmentTree: (state) => state.environment.environmentTree,
      // 服务器列表
      serverList: (state) => state.serverList.serverList,
    }),

    // 处理环境列表单选框类目
    getEnvironmentOptions() {
      // 定义一个空数组 最终与data中的数组合并
      let options = [];
      // 遍历环境tree
      this.environmentTree.forEach((item, index) => {
        // 定义对象，给对象赋值
        let obj = {
          value: item.id,
          label: item.envName,
          children: [],
        };
        // 把对象加入到空数组中
        options.push(obj);
        // 遍历每个环境的子环境tree
        item.children.forEach((childrenItem) => {
          // 定义子环境对象
          let objChildren = {
            value: childrenItem.id,
            label: childrenItem.envName,
          };
          // 把子环境对象加入到对应的子环境数组中
          options[index].children.push(objChildren);
        });
      });
      // 合并数组
      return [{ value: 0, label: "DCI", children: [] }, ...options];
    },

    // 初始化服务器列表数据
    getServerData() {
      let serverArr = [];
      this.serverList.forEach((item, index) => {
        let serverObj = {
          id: item.id,
          ipAddress: item.ipAddress, //IP地址
          accountAndPassword: [], //账号密码
          envInfo: this.getEnvInfo(item.envId),
          descriptionLabel: item.description ? item.description.split("/") : [], //标签
          status: item.status,
        };
        serverArr.push(serverObj);

        for (let account in item.accountInfos) {
          let accountInfoObj = {
            name: account,
            user: item.accountInfos[account].split("/")[0],
            pwd: item.accountInfos[account].split("/")[1],
          };
          serverArr[index].accountAndPassword.push(accountInfoObj);
        }
      });
      return serverArr;
    },

    // 筛选服务器列表数据做展示
    fliterServerData() {
      const { val0, val1, val2 } = this.fliterObj;
      let fliterServerData = this.getServerData;
      // 筛选实例环境类目
      if (val0.length > 0) {
        fliterServerData = fliterServerData.filter((item) => {
          if (val0.length == 1) {
            return item.envInfo.env1Id == val0[0];
          } else if (val0.length == 2) {
            return item.envInfo.env2Id == val0[1];
          }
        });
      }
      // 筛选实例运行状态
      if (val1 !== "") {
        fliterServerData = fliterServerData.filter((item) => {
          return item.status == val1;
        });
      }
      // 模糊搜索
      if (val2 !== "") {
        let description = "";
        fliterServerData = fliterServerData.filter((item) => {
          description = `${item.descriptionLabel.join("")}${item.ipAddress}`;
          return description.indexOf(val2) !== -1;
        });
      }
      return fliterServerData;
    },
  },
};
</script>

<style lang="less" scoped>
#serverList {
  // border: 1px solid red;
  height: 100%;
  
  .title {
    // border: 1px solid red;
    color: #252b3a;
    font-size: 16px;
    font-weight: 700;
    margin-right: 10px;
  }

  .hwsicon {
    // border: 1px solid red;
    font-size: 16px;
  }

  .operation {
    display: flex;
    justify-content: space-between;

    .left {
      // border: 1px solid red;
      display: flex;

      button {
        background-color: #f5f5f6;
        border: 1px solid #dfe1e6;
        border-radius: 2px;
        height: 28px;
        padding: 0px 20px;
        font-size: 12px;
        color: #adb0b8;
        margin-right: 4px;
        cursor: not-allowed;
      }

      button:nth-of-type(1) {
        border-color: #adb0b8;
        background-color: #fff;
        color: #252b3a;
        cursor: pointer;
      }

      button:nth-of-type(1):hover {
        border-color: #5e7ce0;
        color: #526ecc;
      }
    }

    .right {
      display: flex;

      button {
        height: 28px;
        width: 28px;
        background-color: #fff;
        border: 1px solid #adb0b8;
        border-radius: 2px;
        margin: 0 4px;
        padding-top: 3px;
        cursor: not-allowed;
      }

      .split {
        height: 24px;
        border-left: 1px solid #adb0b8;
        margin: 2px 4px;
      }

      button:nth-of-type(1) {
        cursor: pointer;
      }

      button:nth-of-type(4) {
        border-color: #5e7ce0;
        fill: #526ecc;
        cursor: pointer;
      }
    }
  }

  .query {
    display: flex;
    margin-top: 20px;
    align-items: center;
    line-height: 28px;

    .el-cascader {
      width: 360px;
      margin-right: 10px;
    }

    .el-select {
      width: 360px;
      margin-right: 10px;
    }

    .el-input {
      .el-input__icon {
        // border: 1px solid red;
        line-height: 33px;
      }
    }
  }

  .el-table {
    /deep/.table_header_class th {
      background: rgb(242, 245, 252);
      color: rgb(87, 93, 108);
      font-size: 12px;
      padding: 2px;
      border-right: 1px solid rgb(255, 255, 255);
    }

    .el-form {
      border: 1px solid red;
      width: 250px;
      display: inline-block;

      .el-form-item {
        margin-bottom: 0;

        span {
          display: block;
          line-height: 20px;
        }
      }
    }

    .el-tag {
      margin: 0 5px;
    }

    .el-button:nth-of-type(1) {
      // border: 1px solid red;
      cursor: not-allowed;
    }

    .iconfont {
      // border: 1px solid red;
      margin-left: 5px;
      font-size: 10px;
      color: #adb0b8;
      cursor: pointer;
    }

    .iconfont:hover {
      color: #7693f5;
    }
  }
}
</style>