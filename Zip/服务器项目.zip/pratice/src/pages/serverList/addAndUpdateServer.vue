<template>
  <div>
    <el-dialog
      :title="form.id ? '修改服务器实例' : '新增服务器实例'"
      :visible.sync="dialogFormVisible"
      :before-close="closeDialog"
      width="700px"
    >
      <el-form size="mini" :rules="rules" ref="form" :model="form">
        <el-form-item label="实例状态" label-width="100px" prop="status">
          <el-radio-group v-model="form.status">
            <el-radio :label="1">正在使用</el-radio>
            <el-radio :label="2">已经释放</el-radio>
            <el-radio :label="3">未使用</el-radio>
            <el-radio v-show="form.id" :label="0">删除（危险操作）</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="实例IP" label-width="100px" prop="ipAddress">
          <el-input
            size="mini"
            style="width: 60%"
            v-model="form.ipAddress"
          ></el-input>
        </el-form-item>
        <el-form-item label="实例类目" label-width="100px" prop="envInfo">
          <el-cascader
            :options="environmentOptions"
            :props="{ checkStrictly: true }"
            v-model="form.envInfo"
            clearable
            size="mini"
            style="width: 60%"
          ></el-cascader>
        </el-form-item>
        <el-form-item
          v-show="isShow"
          :label="`账号密码${accountInfo.id + 1}`"
          label-width="100px"
          v-for="(accountInfo, index) in form.accountAndPassword"
          :key="accountInfo.id"
        >
          <el-col :span="5" style="margin-right: 20px"
            ><el-input
              size="mini"
              placeholder="linux_root"
              v-model="accountInfo.name"
            ></el-input
          ></el-col>
          <el-col :span="4" style="margin-right: 20px"
            ><el-input
              size="mini"
              placeholder="root"
              v-model="accountInfo.user"
            ></el-input
          ></el-col>
          <el-col :span="8" style="margin-right: 20px"
            ><el-input
              size="mini"
              placeholder="b$y03KL#cIFl0v"
              v-model="accountInfo.pwd"
            ></el-input
          ></el-col>
          <span @click="deleteAccount(index)" style="cursor: pointer"
            >删除</span
          >
        </el-form-item>
        <el-form-item label="标签" label-width="100px" prop="descriptionLabel">
          <el-input
            type="textarea"
            rows="4"
            placeholder="请输入内容"
            style="width: 80%"
            v-model="form.descriptionLabel"
          >
          </el-input>
        </el-form-item>
        <el-form-item
          ><span style="margin-left: 100px"
            >标签用"/"隔开，例如：<span style="color: red"
              >业务/数据库/注册中心</span
            >，没有请写 <span style="color: red">无</span></span
          ></el-form-item
        >
        <el-form-item style="margin-left: 100px">
          <el-button type="primary" size="mini" @click="submitForm()">{{
            form.id ? "立即修改" : "立即新增"
          }}</el-button>
          <el-button size="mini" @click="addAccount">新增账号密码</el-button>
          <el-button size="mini" v-show="form.id" @click="reset"
            >重置</el-button
          ></el-form-item
        >
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import { reqAddOrUpdateServerInfo } from "../../api/serverList";
export default {
  name: "AddAndUpdateServer",
  props: {
    // 控制dialog是否展示
    dialogFormVisible: Boolean,
    // 关闭dialog
    closeDialogForm: Function,
    // 实例类目选择器数据
    environmentOptions: Array,
    // 修改时的服务器信息
    serverInfo: Object,
  },
  data() {
    var validateIpAddress = (rule, value, callback) => {
      let ipAddressReg =
        /^((25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))$/;
      if (!ipAddressReg.test(value)) {
        return callback(new Error("请输入正确的ip地址"));
      } else {
        callback();
      }
    };
    var validateDescription = (rule, value, callback) => {
      if (!value.trim()) {
        return callback(new Error("标签不能为空 请输入正确的值"));
      } else {
        callback();
      }
    };
    return {
      form: {
        id: "",
        accountAndPassword: [],
        descriptionLabel: "",
        envInfo: [],
        ipAddress: "",
        status: "",
      },
      // 控制账号密码输入框显示
      isShow: false,
      // 表单验证规则
      rules: {
        status: [
          { required: true, message: "请选择实例状态", trigger: "change" },
        ],
        ipAddress: [
          { required: true, message: "请输入服务器ip", trigger: "blur" },
          { validator: validateIpAddress, trigger: "blur" },
        ],
        envInfo: [
          { required: true, message: "请选择实例类目", trigger: "change" },
        ],
        descriptionLabel: [
          { required: true, message: "请填写服务器实例标签", trigger: "blur" },
          { validator: validateDescription, trigger: "blur" },
        ],
      },
    };
  },
  watch: {
    // 监控父组件传来的服务器信息变化 处理初始数据
    serverInfo: {
      handler(newVal, oldVal) {
        // this.reset();
        // 初始化
        this.form = {
          id: "",
          accountAndPassword: [],
          descriptionLabel: "",
          envInfo: [],
          ipAddress: "",
          status: "",
        };
        const {
          id,
          accountAndPassword,
          descriptionLabel,
          envInfo,
          ipAddress,
          status,
        } = this.serverInfo;

        this.form.id = id;
        this.form.ipAddress = ipAddress;
        this.form.status = status;

        // 修改传过来的服务器信息的实例类目信息 将对象转换成数组
        if (!envInfo.env2Id) {
          this.form.envInfo = [envInfo.env1Id];
        } else {
          this.form.envInfo = [envInfo.env1Id, envInfo.env2Id];
        }
        // this.form.envInfo = [];
        // this.form.envInfo.push(envInfo.env1Id);
        // this.form.envInfo.push(envInfo.env2Id);
        // this.form.envInfo.splice(0, 2, envInfo.env1Id, envInfo.env2Id);

        // 修改传过来的服务器信息的标签信息 将数组转换成字符串
        if (descriptionLabel) {
          this.form.descriptionLabel = descriptionLabel.join("/");
        }
        // 加上id字段
        if (accountAndPassword) {
          accountAndPassword.forEach((item, index) => {
            let obj = {
              id: index,
              name: item.name,
              pwd: item.pwd,
              user: item.user,
            };
            this.form.accountAndPassword.push(obj);
          });
        }
      },
    },
    // 监控账户密码 不为空的时候控制显示
    form: {
      deep: true,
      handler(newVal, oldVal) {
        if (this.form.accountAndPassword.length == 0) {
          this.isShow = false;
        } else {
          this.isShow = true;
        }
      },
    },
  },
  methods: {
    // 重置按钮的回调
    reset() {
      this.$refs["form"].resetFields();
    },
    // 关闭对话框的回调 关闭对话框时将dialog数据重置
    closeDialog() {
      this.$refs["form"].resetFields();
      // 调用父组件关闭对话框方法
      this.closeDialogForm();
    },
    // 点击新增账号密码的回调
    addAccount() {
      const obj = {
        id: this.form.accountAndPassword.length,
        name: "",
        pwd: "",
        user: "",
      };
      this.form.accountAndPassword.push(obj);
    },
    // 点击删除账号密码的回调
    deleteAccount(index) {
      this.form.accountAndPassword.splice(index, 1);
    },

    // 修改/新增的回调
    submitForm() {
      this.$refs["form"].validate((valid) => {
        if (valid) {
          this.addOrUpdateServerInfo();
        } else {
          this.$message({
            message: "提交失败 请检查服务器实例填写是否正确",
            showClose: true,
            type: "error",
          });
          return false;
        }
      });
    },

    // 发送增加/修改的ajax请求
    async addOrUpdateServerInfo() {
      let { descriptionLabel, envInfo, id, ipAddress, status } = this.form;
      let serverInfo = {
        accountInfos: this.getAccountInfos(), //需要处理
        description: descriptionLabel,
        envId: envInfo.length == 1 ? envInfo[0] : envInfo[1],
        id: id,
        ipAddress: ipAddress,
        status: status,
      };
      let result = await reqAddOrUpdateServerInfo(serverInfo);
      if (result.code == 200) {
        this.$message({
          message: serverInfo.id ? "修改成功" : "新增成功",
          showClose: true,
          type: "success",
        });
        // 关闭对话框
        this.closeDialog();
      }
    },

    // 处理账号密码信息 将其转换为对象
    getAccountInfos() {
      let { accountAndPassword } = this.form;
      let accountInfos = {};
      accountAndPassword.forEach((item) => {
        accountInfos[item.name] = `${item.user}/${item.pwd}`;
      });
      return accountInfos;
    },
  },
  computed: {},
};
</script>

<style lang="less" scoped>
</style>