<template>
  <div id="dataBoard">
    <span class="title">数据看板</span>
    <el-popover
      popper-class="base-header-popper"
      trigger="hover"
      width="360"
      placement="right-start"
      content="DCI服务器控制台是可以方便组员快速查看服务器配置状态的小工具，通过数据看板，可以方便直观的了解服务器群当前生产状态。"
    >
      <el-icon slot="reference" class="hwsicon icon-cloud-action-tip"></el-icon>
    </el-popover>
  </div>
</template>

<script>
export default {
  name: "DataBoard",
};
</script>

<style lang="less" scoped>
#dataBoard {
  .title {
    // border: 1px solid red;
    color: #252b3a;
    font-size: 16px;
    font-weight: 700;
    margin-right: 10px;
  }

  .hwsicon {
    // border: 1px solid red;
    font-size: 16px;
  }
}
</style>