<template>
  <div>
    <el-card>
      <CategorySelect
        :showTable="scene == 0"
        :getCategoryId="getCategoryId"
      ></CategorySelect>
    </el-card>
    <el-card style="margin-top: 20px">
      <div v-show="scene == 0">
        <el-button
          type="primary"
          icon="el-icon-plus"
          @click="addSpu"
          :disabled="!categoryIdList.category3Id"
          >添加SPU</el-button
        >
        <el-table :data="spuList" style="width: 100%" border>
          <el-table-column type="index" label="序号" width="80" align="center">
          </el-table-column>
          <el-table-column prop="spuName" label="SPU名称" width="400">
          </el-table-column>
          <el-table-column prop="description" label="SPU描述" width="800">
          </el-table-column>
          <el-table-column prop="prop" label="操作" width="width">
            <template slot-scope="{ row, $index }">
              <el-button
                type="success"
                size="mini"
                @click="addSku(row)"
                title="添加sku"
                icon="el-icon-plus"
              ></el-button>
              <el-button
                type="warning"
                size="mini"
                @click="editSpu(row)"
                title="修改spu"
                icon="el-icon-edit"
              ></el-button>
              <el-button
                type="info"
                size="mini"
                title="查看当前spu全部sku列表"
                icon="el-icon-info"
                style="margin-right: 10px"
                @click="showSkuInfo(row)"
              ></el-button>
              <el-popconfirm title="确定删除吗？" @onConfirm="deleteSpu(row)">
                <el-button
                  type="danger"
                  size="mini"
                  title="删除spu"
                  icon="el-icon-delete"
                  slot="reference"
                ></el-button>
              </el-popconfirm>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          :current-page="pageNum"
          :page-sizes="[3, 5, 10]"
          :page-size="pageSize"
          layout="prev, pager, next, jumper, ->, sizes, total"
          :total="total"
          style="text-align: center; margin-top: 20px"
          @size-change="handleSizeChange"
          @current-change="getSpuList"
        >
        </el-pagination>
      </div>

      <!-- 添加/修改spu -->
      <SpuForm
        v-show="scene == 1"
        @changeScene="changeScene"
        ref="spu"
      ></SpuForm>
      <!-- 添加sku -->
      <SkuForm
        v-show="scene == 2"
        @changeScene="changeScene"
        ref="sku"
      ></SkuForm>

      <!--@close="closeDialog(row, $index)" -->
      <el-dialog
        :title="`${spu.spuName}的sku列表`"
        :visible.sync="dialogTableVisible"
        :before-close="close"
      >
        <el-table border :data="skuInfo" v-loading="loading">
          <el-table-column
            prop="skuName"
            label="名称"
            width="width"
          ></el-table-column>
          <el-table-column
            prop="price"
            label="价格"
            width="width"
          ></el-table-column>
          <el-table-column
            prop="weight"
            label="重量"
            width="width"
          ></el-table-column>
          <el-table-column label="默认图片" width="width">
            <template slot-scope="{ row }">
              <img
                :src="row.skuDefaultImg"
                style="width: 100px; height: 100px"
              /> </template
          ></el-table-column>
        </el-table>
      </el-dialog>
    </el-card>
  </div>
</template>

<script>
import SpuForm from "./SpuForm";
import SkuForm from "./SkuForm";

export default {
  name: "",
  components: { SpuForm, SkuForm },
  data() {
    return {
      dialogTableVisible: false,
      categoryIdList: {},
      scene: 0, //最终要改回0
      spuList: [],
      pageNum: 1,
      pageSize: 3,
      total: 0,
      skuInfo: [],
      loading: true,
      spu: {},
    };
  },
  methods: {
    // 获取到三级联动组件的id
    getCategoryId(categoryIdList) {
      this.categoryIdList = categoryIdList;
      this.getSpuList();
    },
    // 发请求获取数据
    async getSpuList(page = 1) {
      this.pageNum = page;
      let { category3Id } = this.categoryIdList;
      let result = await this.$API.spu.reqSpuList(
        this.pageNum,
        this.pageSize,
        category3Id
      );
      if (result.code == 200) {
        this.spuList = result.data.records;
        // this.spuList = result.data.records.map((item) => {
        //   item.dialogTableVisible = false;
        //   return item;
        // });
        this.total = result.data.total;
      }
    },
    // 修改当前页的回调
    // handleCurrentChange(page) {
    //   this.pageNum = page;
    //   this.getSpuList();
    // },
    // 修改每页条数的回调
    handleSizeChange(size) {
      this.pageSize = size;
      this.getSpuList();
    },
    // spu和sku取消按钮 切换场景
    changeScene(obj) {
      const { scene, flag } = obj;
      this.scene = scene;
      if (flag == "add") {
        // 添加后返回第一页
        this.getSpuList();
      } else {
        // 修改后返回当前页
        this.getSpuList(this.pageNum);
      }
    },
    // 修改spu
    editSpu(row) {
      this.scene = 1;
      this.$refs.spu.editData(row);
    },
    // 添加spu
    addSpu() {
      this.scene = 1;
      this.$refs.spu.addData(this.categoryIdList.category3Id);
    },
    // 删除spu
    async deleteSpu(row) {
      let result = await this.$API.spu.reqDeleteSpu(row.id);
      if (result.code == 200) {
        this.$message({ type: "success", message: "删除成功" });
        this.getSpuList(this.pageNum);
      }
    },
    // 添加sku
    addSku(row) {
      this.scene = 2;
      this.$refs.sku.addSkuData(row, this.categoryIdList);
    },
    // 查看sku列表
    async showSkuInfo(row) {
      // row.dialogTableVisible = true;
      this.dialogTableVisible = true;
      this.spu = row;
      let result = await this.$API.spu.reqSkuInfo(row.id);
      if (result.code == 200) {
        this.skuInfo = result.data;
        this.loading = false;
      }
    },
    // 自定义关闭对话框
    // closeDialog(row, index) {
    //   // 这种改法不是响应式 页面不刷新 无法正常关闭
    //   // row.dialogTableVisible = false;
    //   this.spuList.splice(index, 1, row);
    //   this.loading = true;
    // },
    close(done) {
      done();
      this.loading = true;
      this.skuInfo = [];
    },
  },
};
</script>

<style scoped>
</style>