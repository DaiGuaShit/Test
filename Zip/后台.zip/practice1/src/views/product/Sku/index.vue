<template>
  <div>
    <el-table :data="skuList" style="width: 100%" border>
      <el-table-column type="index" label="序号" width="80" align="center">
      </el-table-column>
      <el-table-column prop="skuName" label="名称" width="width">
      </el-table-column>
      <el-table-column prop="skuDesc" label="描述" width="width">
      </el-table-column>
      <el-table-column label="默认图片" width="width">
        <template slot-scope="{ row }">
          <img :src="row.skuDefaultImg" style="height: 100px; width: 100px" />
        </template>
      </el-table-column>
      <el-table-column prop="weight" label="重量" width="width">
      </el-table-column>
      <el-table-column prop="price" label="价格" width="width">
      </el-table-column>
      <el-table-column label="操作" width="300">
        <template slot-scope="{ row }">
          <el-button
            v-if="row.isSale == 0"
            type="success"
            size="mini"
            icon="el-icon-top"
            @click="onSale(row)"
          ></el-button>
          <el-button
            v-else
            type="success"
            size="mini"
            icon="el-icon-bottom"
            @click="cancelSale(row)"
          ></el-button>
          <el-button
            type="primary"
            size="mini"
            icon="el-icon-edit"
            @click="editSku"
          ></el-button>
          <el-button
            type="info"
            size="mini"
            icon="el-icon-info"
            @click="getSkuInfo(row)"
          ></el-button>
          <el-button
            type="danger"
            size="mini"
            icon="el-icon-delete"
          ></el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页器 -->
    <el-pagination
      :current-page="pageNum"
      :page-sizes="[3, 5, 10]"
      :page-size="pageSize"
      layout="prev, pager, next, jumper, ->, sizes, total"
      :total="totalCount"
      style="text-align: center"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    >
    </el-pagination>
    <!-- 抽屉 -->
    <!-- :before-close="handleClose" -->
    <el-drawer :visible.sync="dialog" :show-close="false" size="40%">
      <el-row>
        <el-col :span="5">名称</el-col>
        <el-col :span="16">{{ skuInfo.skuName }}</el-col>
      </el-row>
      <el-row>
        <el-col :span="5">描述</el-col>
        <el-col :span="16">{{ skuInfo.skuDesc }}</el-col>
      </el-row>
      <el-row>
        <el-col :span="5">价格</el-col>
        <el-col :span="16">{{ skuInfo.price }}</el-col>
      </el-row>
      <el-row>
        <el-col :span="5">平台属性</el-col>
        <el-col :span="16">
          <el-tag
            type="success"
            v-for="skuAttrValue in skuInfo.skuAttrValueList"
            :key="skuAttrValue.id"
            style="margin: 0 10px"
            >{{ skuAttrValue.attrId }}-{{ skuAttrValue.valueId }}</el-tag
          >
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="5">商品图片</el-col>
        <el-col :span="10">
          <el-carousel trigger="click" height="300px">
            <el-carousel-item
              v-for="skuImage in skuInfo.skuImageList"
              :key="skuImage.id"
            >
              <img :src="skuImage.imgUrl" style="height: 300px; width: 300px" />
            </el-carousel-item>
          </el-carousel>
        </el-col>
        <el-col :span="9"></el-col>
      </el-row>
    </el-drawer>
  </div>
</template>

<script>
export default {
  name: "",
  data() {
    return {
      skuList: [],
      skuInfo: {},
      totalCount: 0,
      pageSize: 5,
      pageNum: 1,
      dialog: false,
    };
  },
  mounted() {
    this.getSkuList();
  },
  methods: {
    // 获取sku列表
    async getSkuList() {
      let result = await this.$API.sku.reqSkuList(this.pageNum, this.pageSize);
      if (result.code == 200) {
        this.skuList = result.data.records;
        this.totalCount = result.data.total;
      }
    },
    handleSizeChange(size) {
      this.pageSize = size;
      this.getSkuList();
    },
    handleCurrentChange(page) {
      this.pageNum = page;
      this.getSkuList();
    },
    async onSale(row) {
      let result = await this.$API.sku.reqOnSale(row.id);
      if (result.code == 200) {
        this.$message({ type: "success", message: "上架成功" });
        this.getSkuList();
      }
    },
    async cancelSale(row) {
      let result = await this.$API.sku.reqCancelSale(row.id);
      if (result.code == 200) {
        this.$message({ type: "success", message: "下架成功" });
        this.getSkuList();
      }
    },
    editSku() {
      this.$message({ type: "info", message: "该功能正在开发中，暂不可用" });
    },
    async getSkuInfo(row) {
      let result = await this.$API.sku.reqSkuById(row.id);
      if (result.code == 200) {
        this.skuInfo = result.data;
      }
      this.dialog = true;
    },
  },
};
</script>

<style>

</style>

<style scoped>
/* /deep/.el-table__header-wrapper{
  border: 1px solid red;
} */

.el-col {
  font-size: 15px;
  margin: 10px 10px;
}
.el-col-5 {
  text-align: right;
}
</style>
<style>
.el-carousel__button {
  width: 10px;
  height: 10px;
  background: pink;
  border-radius: 50%;
}
</style>