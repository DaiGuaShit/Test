import request from "@/utils/request";

// 获取品牌管理数据
// /admin/product/baseTrademark/{page}/{limit}
export const reqTradeMarkList = (page, limit) =>
  request({
    url: `/admin/product/baseTrademark/${page}/${limit}`,
    method: "GET",
  });

// 添加品牌
// /admin/product/baseTrademark/save   post  携带两个参数：品牌名称、品牌logo

// 修改品牌
// /admin/product/baseTrademark/update   put   携带三个参数：id、品牌名称、品牌logo
export const reqAddOrEditTradeMark = (tradeMark) => {
  if (tradeMark.id) {
    return request({
      url: "/admin/product/baseTrademark/update",
      method: "PUT",
      data: tradeMark,
    });
  } else {
    return request({
      url: "/admin/product/baseTrademark/save",
      method: "POST",
      data: tradeMark,
    });
  }
};

//删除品牌
// /admin/product/baseTrademark/remove/{id}  delete
export const reqDeleteTradeMark = (id) =>
  request({
    url: `/admin/product/baseTrademark/remove/${id}`,
    method: "DELETE",
  });
