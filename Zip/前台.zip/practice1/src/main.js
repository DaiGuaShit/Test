import Vue from "vue";
import App from "@/App";
import router from "@/router";
// 引入全局组件
import TypeNav from "@/components/TypeNav";
import Carousel from "@/components/Carousel";
import Pagination from "@/components/Pagination"
// 引入仓库
import store from "@/store";

import "@/mock/moskServe";

import "swiper/css/swiper.css";
// 注册全局组件
Vue.component(TypeNav.name, TypeNav);
Vue.component(Carousel.name, Carousel);
Vue.component(Pagination.name, Pagination);

Vue.config.productionTip = false;

new Vue({
  beforeCreate() {
    Vue.prototype.$bus = this;
  },
  el: "#app",
  render: (h) => h(App),
  router,
  store,
});
