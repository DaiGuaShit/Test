import Home from "@/views/Home";
import Search from "@/views/Search";
import Detail from "@/views/Detail";

export default [
  {
    path: "/home",
    component: Home,
    meta: { showFooter: true },
  },
  {
    path: "/search/:keyword?",
    component: Search,
    meta: { showFooter: true },
    name: "search",
  },
  {
    path: "/detail/:skuId",
    component: Detail,
    meta: { showFooter: false },
  },
  {
    path: "*",
    redirect: "/home",
  },
];
