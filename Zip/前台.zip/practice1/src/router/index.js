import Vue from "vue";
import VueRouter from "vue-router";
import routes from "./routes"

Vue.use(VueRouter);

// 重写VueRouter原型对象的push和replace方法
let originPush = VueRouter.prototype.push;
let originReplace = VueRouter.prototype.replace;

VueRouter.prototype.push = function (loction, resolve, reject) {
  if (resolve && reject) {
    originPush.call(this, loction, resolve, reject);
  } else {
    originPush.call(
      this,
      loction,
      () => {},
      () => {}
    );
  }
};
VueRouter.prototype.replace = function (loction, resolve, reject) {
  if (resolve && reject) {
    originReplace.call(this, loction, resolve, reject);
  } else {
    originReplace.call(
      this,
      loction,
      () => {},
      () => {}
    );
  }
};

export default new VueRouter({
  routes,
  scrollBehavior(to, from, savedPosition) {
    // return 期望滚动到哪个的位置
    return { y: 0 };
  },
});
