<template>
  <div class="pagination">
    <button :disabled="pageNo == 1" @click="getPageNo(pageNo - 1)">
      上一页
    </button>
    <button
      v-if="startNumAndEndNum.startNum > 1"
      @click="getPageNo(1)"
      :class="{ active: pageNo == 1 }"
    >
      1
    </button>
    <button v-if="startNumAndEndNum.startNum > 2">···</button>

    <button
      v-for="(page, index) in startNumAndEndNum.endNum"
      :key="index"
      v-if="page >= startNumAndEndNum.startNum"
      @click="getPageNo(page)"
      :class="{ active: pageNo == page }"
    >
      {{ page }}
    </button>

    <button v-if="startNumAndEndNum.endNum < totalPage - 1">···</button>
    <button
      v-if="startNumAndEndNum.endNum < totalPage"
      @click="getPageNo(totalPage)"
      :class="{ active: pageNo == totalPage }"
    >
      {{ totalPage }}
    </button>
    <button :disabled="pageNo == totalPage" @click="getPageNo(pageNo + 1)">
      下一页
    </button>

    <button style="margin-left: 30px">共 {{ total }} 条</button>
  </div>
</template>

<script>
export default {
  name: "Pagination",
  props: ["pageNo", "pageSize", "total", "continues", "getPageNo"],
  computed: {
    // 计算总页数
    totalPage() {
      return Math.ceil(this.total / this.pageSize);
    },
    // 计算连续页码的开始数字和结束数字
    startNumAndEndNum() {
      const { pageNo, totalPage, continues } = this;
      let startNum;
      let endNum;
      // 不正常情况1：总页数<连续页数
      if (totalPage < continues) {
        startNum = 1;
        endNum = totalPage;
      } else {
        // 正常情况：总页数>连续页数
        startNum = pageNo - parseInt(continues / 2);
        endNum = pageNo + parseInt(continues / 2);
        // 不正常情况2：比如连续页数5 当前点击页数1或者页数2
        if (startNum < 1) {
          startNum = 1;
          endNum = startNum + continues - 1;
        }
        // 不正常情况2：比如连续页数5 总页数10 当前点击页数9或者页数10
        if (endNum > totalPage) {
          endNum = totalPage;
          startNum = totalPage - continues + 1;
        }
      }

      return { startNum, endNum };
    },
  },
};
</script>

<style lang="less" scoped>
.pagination {
  text-align: center;
  button {
    margin: 0 5px;
    background-color: #f4f4f5;
    color: #606266;
    outline: none;
    border-radius: 2px;
    padding: 0 4px;
    vertical-align: top;
    display: inline-block;
    font-size: 13px;
    min-width: 35.5px;
    height: 28px;
    line-height: 28px;
    cursor: pointer;
    box-sizing: border-box;
    text-align: center;
    border: 0;

    &[disabled] {
      color: #c0c4cc;
      cursor: not-allowed;
    }

    &.active {
      cursor: not-allowed;
      background-color: #409eff;
      color: #fff;
    }
  }
}
</style>