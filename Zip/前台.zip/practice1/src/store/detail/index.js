import { reqGetDetailInfo } from "@/api";

const state = {
  detailInfo: {},
};

const mutations = {
  GETDETAILINFO(state, detailInfo) {
    state.detailInfo = detailInfo;
  },
};

const actions = {
  async getDetailInfo({ commit }, skuId) {
    let result = await reqGetDetailInfo(skuId);
    if (result.code == 200) {
      commit("GETDETAILINFO", result.data);
    }
  },
};

const getters = {
  // 类目信息
  categoryView(state) {
    return state.detailInfo.categoryView || {};
  },
  // 产品信息
  skuInfo(state) {
    return state.detailInfo.skuInfo || {};
  },
  // 售卖属性
  spuSaleAttrList(state) {
    return state.detailInfo.spuSaleAttrList || [];
  },
};

export default {
  state,
  mutations,
  actions,
  getters,
};
