import requestMock from "./requestMock";
import requestApi from "./requestApi";

// 三级分类接口 /api/product/getBaseCategoryList   GET
export const reqGetCategoryList = () =>
  requestMock.get("/product/getBaseCategoryList");

export const reqGetBannerList = () => requestMock.get("/banner");

export const reqGetFloorList = () => requestMock.get("/floor");

// 搜索模块 /api/list
// 该接口给服务器传递params参数 至少是一个空对象
export const reqGetSearchList = (params) =>
  requestApi({ url: "/list", method: "POST", data: params });

// 商品详情  /api/item/{ skuId }
export const reqGetDetailInfo = (skuId) =>
  requestApi({ url: `/item/${skuId}`, method: "GET" });
