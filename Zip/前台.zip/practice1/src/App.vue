<template>
  <div>
    <Header />
    <router-view></router-view>
    <Footer v-show="$route.meta.showFooter" />
  </div>
</template>

<script>
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default {
  name: "",
  components: {
    Header,
    Footer,
  },
  mounted(){
    this.$store.dispatch("getCategoryList")
  }
};
</script>

<style scoped>
</style>