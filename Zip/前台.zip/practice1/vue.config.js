module.exports = {
  //关闭ESLint
  lintOnSave: false,
  devServer: {
    proxy: {
      "/api": {
        target: "http://gmall-h5-api.atguigu.cn",
        //   changeOrigin:true   //不管改变哪个跨域的条件都会转发
      },
    },
  },
};
