import request from "@/utils/request";

//获取SPU列表数据的接口
///admin/product/{page}/{limit}   get   page limit category3Id
export const reqSpuList = (page, limit, category3Id) =>
  request({
    url: `/admin/product/${page}/${limit}`,
    method: "GET",
    params: { category3Id },
  });

// 添加spu时 需要获取品牌、销售属性数据
// 修改spu时 需要获取详情、品牌、销售属性、图片数据

//获取SPU信息
///admin/product/getSpuById/{spuId}   get
export const reqSpuDetail = (spuId) =>
  request({
    url: `/admin/product/getSpuById/${spuId}`,
    method: "GET",
  });

//获取品牌的信息
///admin/product/baseTrademark/getTrademarkList  get
export const reqTrademarkList = () =>
  request({
    url: `/admin/product/baseTrademark/getTrademarkList`,
    method: "GET",
  });

//获取SPU图标的接口
///admin/product/spuImageList/{spuId}  get
export const reqSpuImageList = (spuId) =>
  request({
    url: `/admin/product/spuImageList/${spuId}`,
    method: "GET",
  });

//获取平台全部销售属性----整个平台销售属性一共三个
//GET /admin/product/baseSaleAttrList
export const reqBaseSaleAttrList = () =>
  request({
    url: `/admin/product/baseSaleAttrList`,
    method: "GET",
  });

// 修改/添加SPU 修改的参数带id
// /admin/product/updateSpuInfo post
// /admin/product/saveSpuInfo post
export const saveOrUpdateSpuInfo = (spuInfo) => {
  if (spuInfo.id) {
    return request({
      url: `/admin/product/updateSpuInfo`,
      method: "POST",
      data: spuInfo,
    });
  } else {
    return request({
      url: `/admin/product/saveSpuInfo`,
      method: "POST",
      data: spuInfo,
    });
  }
};

//删除SPU
///admin/product/deleteSpu/{spuId}
export const reqDeleteSpu = (spuId) =>
  request({
    url: `/admin/product/deleteSpu/${spuId}`,
    method: "DELETE",
  });

// 获取销售属性
// /admin/product/spuSaleAttrList/{spuId} get
export const reqSaleAttrList = (spuId) =>
  request({
    url: `/admin/product/spuSaleAttrList/${spuId}`,
    method: "GET",
  });

//获取平台属性
// /admin/product/attrInfoList/{category1Id}/{category2Id}/{category3Id} get
export const reqAttrInfoList = (category1Id, category2Id, category3Id) =>
  request({
    url: `/admin/product/attrInfoList/${category1Id}/${category2Id}/${category3Id}`,
    method: "GET",
  });

// 添加Sku
// /admin/product/saveSkuInfo  post
export const reqSaveSkuInfo = (skuInfo) =>
  request({
    url: `/admin/product/saveSkuInfo`,
    method: "POST",
    data: skuInfo,
  });

//获取SKU列表数据的接口
//GET /admin/product/findBySpuId/{spuId}
export const reqSkuInfo = (spuId) =>
  request({
    url: `/admin/product/findBySpuId/${spuId}`,
    method: "GET",
  });
