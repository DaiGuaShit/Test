<template>
  <div class="dashboard-container">
    <div class="before"></div>
    <el-button @click="sureSava">裁剪</el-button>
    <div class="container">
      <div class="img-container">
        <img src="@/assets/test1.png" ref="image" alt="" />
      </div>
      <div class="afterCropper">
        <img :src="afterImg" alt="" />
      </div>
    </div>
  </div>
</template>

<script>
import Cropper from "cropperjs";
import "cropperjs/dist/cropper.css";
export default {
  data() {
    return {
      myCropper: null,
      afterImg: "",
    }
  },
  created() {
    this.$nextTick(() => {
      this.init();
    })
  },
  methods: {
    init() {
      this.myCropper = new Cropper(this.$refs.image, {
        viewMode: 3, // 视图模式，1：限制裁剪框不超过画布的大小
        // 0：没有限制，3可以移动到2外。 
        // 1 : 3只能在2内移动。 
        // 2：2图片 不全部铺满1 （即缩小时可以有一边出现空隙） 
        // 3：2图片填充整个1
        dragMode: 'move', // 拖动模式
        aspectRatio: 1, // 裁剪框的固定纵横比，裁剪区默认正方形
        autoCropArea: 1, // 自动裁剪区域，0~1自动裁剪区域大小（百分比）
        cropBoxMovable: false, // 裁剪框是否能移动
        cropBoxResizable: false, // 裁剪框是否缩放
        background: false, // 默认背景
        movable: true, // 移动图片
        guides: false // 显示在裁剪框上方的虚线
        // cropper.js中的参数：
        // 1、viewMode—定义cropper的视图模式
        // cropper.png
        // 0：没有限制，3可以移动到2外。 
        // 1 : 3只能在2内移动。 
        // 2：2图片 不全部铺满1 （即缩小时可以有一边出现空隙） 
        // 3：2图片填充整个1
        // 2、dragMode —-定义cropper的拖拽模式。
        // 类型: String 
        // 默认: ‘crop’ 
        // 选项: 
        // ‘crop’: 可以产生一个新的裁剪框
        // ‘move’: 只可以移动
        // ‘none’: 什么也不处理
        // 3、responsive—在调整窗口大小的时候重新渲染cropper
        // 类型：Boolean 默认：true；
        // 4、restore—在调整窗口大小后恢复裁剪的区域。
        // 类型：Boolean 默认：true；
        // 5、checkCrossOrigin—-检查当前图像是否为跨域图像。
        // 类型：Boolean 默认：true；
        // 6、guides—显示在裁剪框上方的虚线。
        // 类型：Boolean 默认：true； 
        // 7、highlight–在裁剪框上方显示白色的区域(突出裁剪框)。
        // 类型：Boolean 默认：true；
        // 8、background–显示容器的网格背景。（就是后面的马赛克）
        // 类型：Boolean 默认：true； 
        // 9、autoCropArea–定义自动裁剪面积大小(百分比)和图片进行对比。
        // 类型：number 默认：0.8； 
        // 就是裁剪框显示的大小
        // 10、movable–是否允许可以移动后面的图片
        // 类型：Boolean 默认：true；
        // 11、scalable–是否允许缩放图像。
        // 类型：Boolean 默认：true；
        // 12、cropBoxMovable—是否通过拖拽来移动剪裁框。
        // 类型：Boolean 默认：true；
        // 改成false效果图为：剪裁框不可以拖动。
        // 13、cropBoxResizable—是否通过拖动来调整剪裁框的大小。
        // 类型：Boolean 默认：true； 
        // 改成false效果图为：剪裁框不可以调整大小。
        //
        // 作者：Brighten_Sun
        // 链接：https://www.jianshu.com/p/d30dd6217c39
        // 来源：简书
        // 著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
      })
    },
    sureSava() {
      this.afterImg = this.myCropper.getCroppedCanvas({
        imageSmoothingQuality: 'high'
      }).toDataURL('image/jpeg');
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
}

.before {
  width: 100px;
  height: 100px;
  overflow: hidden;
  /* 这个属性可以得到想要的效果 */
}

.img-container {
  height: 400px;
  width: 400px;
  overflow: hidden;
}

.afterCropper {
  flex: 1;
  margin-left: 20px;
  border: 1px solid salmon;
  text-align: center;
}

.afterCropper img {
  width: 150px;
  margin-top: 30px;
}
</style>
