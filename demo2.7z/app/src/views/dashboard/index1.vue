<template>
  <div class="dashboard-container">
    <!-- <div class="dashboard-text">name: {{ name }}</div> -->
    {{ picMulti }}
    <div class="avatar">
      <img :style="{ transform: picMulti }" src="@/assets/test1.png" />
      <div class="maskCircle"></div>
    </div>
    <br />
    <button @click="bigger">放大</button>
    <button @click="smaller">缩小</button>
    <button>上传头像</button>
    <button>保存</button>
  </div>
</template>

<script>
import { mapGetters } from "vuex";

export default {
  name: "Dashboard",
  data() {
    return {
      picMulti: "scale(1)",
    };
  },
  computed: {
    ...mapGetters(["name"]),
  },
  methods: {
    bigger() {
      let num = Number(this.picMulti.split("(")[1].split(")")[0]);
      num += 0.1;
      this.picMulti = `scale(${num.toFixed(1)})`;
    },
    smaller() {
      let num = Number(this.picMulti.split("(")[1].split(")")[0]);
      num -= 0.1;
      this.picMulti = `scale(${num.toFixed(1)})`;
    },
  },
};
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}

.avatar {
  // border: 1px solid red;
  width: 350px;
  height: 350px;
  position: relative;
  overflow: hidden;
  background: #525050;

  img {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    margin: auto;
  }

  .maskCircle {
    width: 350px;
    height: 350px;
    border-radius: 50%;
    box-shadow: 0px 0px 0px 100px rgba(255, 255, 255, 0.8);
    position: absolute;
  }
}
</style>
