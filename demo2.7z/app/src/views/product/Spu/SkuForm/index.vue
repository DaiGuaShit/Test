<template>
  <div>
    <el-form ref="form" label-width="80px">
      <el-form-item label="SPU名称">
        <span>{{ spuInfo.spuName }}</span>
      </el-form-item>
      <el-form-item label="SKU名称">
        <el-input placeholder="SKU名称" v-model="skuInfo.skuName"></el-input>
      </el-form-item>
      <el-form-item label="价格(元)">
        <el-input placeholder="价格(元)" v-model="skuInfo.price"></el-input>
      </el-form-item>
      <el-form-item label="重量(kg)">
        <el-input placeholder="重量(kg)" v-model="skuInfo.weight"></el-input>
      </el-form-item>
      <el-form-item label="规格描述">
        <el-input
          placeholder="规格描述"
          type="textarea"
          rows="4"
          v-model="skuInfo.skuDesc"
        ></el-input>
      </el-form-item>
      <el-form-item label="平台属性">
        <el-form :inline="true">
          <el-form-item
            :label="attrInfo.attrName"
            v-for="attrInfo in attrInfoList"
            :key="attrInfo.id"
            label-width="80px"
          >
            <el-select placeholder="请选择" v-model="attrInfo.attrIdAndValueId">
              <el-option
                :label="attrValue.valueName"
                :value="`${attrValue.attrId}:${attrValue.id}`"
                v-for="attrValue in attrInfo.attrValueList"
                :key="attrValue.id"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </el-form-item>
      <el-form-item label="销售属性">
        <el-form :inline="true">
          <el-form-item
            :label="saleAttr.saleAttrName"
            v-for="saleAttr in saleAttrList"
            :key="saleAttr.id"
            label-width="80px"
          >
            <el-select placeholder="请选择" v-model="saleAttr.attrIdAndValueId">
              <el-option
                :label="saleAttrValue.saleAttrValueName"
                :value="`${saleAttr.id}:${saleAttrValue.id}`"
                v-for="saleAttrValue in saleAttr.spuSaleAttrValueList"
                :key="saleAttrValue.id"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </el-form-item>
      <el-form-item label="图片列表">
        <el-table
          style="width: 100%"
          border
          :data="spuImageList"
          @selection-change="handleSelectionChange"
        >
          <el-table-column type="selection" width="55"> </el-table-column>
          <el-table-column prop="prop" label="图片" width="width">
            <template slot-scope="{ row, $index }">
              <img :src="row.imgUrl" style="width: 100px; height: 100px" />
            </template>
          </el-table-column>
          <el-table-column prop="prop" label="名称" width="width">
            <template slot-scope="{ row, $index }">
              {{ row.imgName }}
            </template>
          </el-table-column>
          <el-table-column prop="prop" label="操作" width="width">
            <template slot-scope="{ row, $index }">
              <el-button
                v-show="row.isDefault == 0"
                type="primary"
                size="mini"
                @click="isDefault($index)"
                >设为默认</el-button
              >
              <el-button
                v-show="row.isDefault == 1"
                type="primary"
                plain
                size="mini"
                >默认</el-button
              >
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="saveSkuInfo">保存</el-button>
        <el-button @click="cancel">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  name: "",
  data() {
    return {
      spuInfo: {},
      spuImageList: [],
      saleAttrList: [],
      attrInfoList: [],
      skuInfo: {
        // 第一类：父组件给的数据
        category3Id: 0,
        spuId: 0,
        tmId: 0,
        // 第二类：双向绑定的数据
        skuName: "",
        price: 0,
        weight: "",
        skuDesc: "",
        // 第三类：代码实现的数据
        skuDefaultImg: "",
        skuAttrValueList: [
          //平台属性
          // {
          // attrId: "106"
          // valueId: "175"
          // },
        ],
        skuImageList: [
          //图片列表
          // {
          // imgName: "1.jpg"
          // imgUrl: "http://139.198.127.41:9000/sph/20220512/1.jpg"
          // isDefault: 1
          // spuImgId: 16669
          // },
        ],
        skuSaleAttrValueList: [
          //销售属性
          // {
          // saleAttrId: "16963"
          // saleAttrValueId: "8835"
          // },
        ],
      },
    };
  },
  methods: {
    // 取消按钮
    cancel() {
      this.$emit("changeScene", { scene: 0, flag: "" });
      Object.assign(this._data, this.$options.data());
    },
    // 初始化数据 发请求
    async addSkuData(spu, categoryIdList) {
      const { category1Id, category2Id, category3Id } = categoryIdList;
      this.skuInfo.category3Id = category3Id;
      this.spuInfo = spu;
      this.skuInfo.spuId = spu.id;
      this.skuInfo.tmId = spu.tmId;

      // 获取SPU图片的接口
      let resultSpuImage = await this.$API.spu.reqSpuImageList(spu.id);
      if (resultSpuImage.code == 200) {
        this.spuImageList = resultSpuImage.data.map((item) => {
          this.$set(item, "isDefault", 0);
          return item;
        });
      }

      // 获取销售属性的接口
      let resultSaleAttr = await this.$API.spu.reqSaleAttrList(spu.id);
      if (resultSaleAttr.code == 200) {
        this.saleAttrList = resultSaleAttr.data;
      }

      // 获取平台属性的接口
      let resultAttrInfo = await this.$API.spu.reqAttrInfoList(
        category1Id,
        category2Id,
        category3Id
      );
      if (resultAttrInfo.code == 200) {
        this.attrInfoList = resultAttrInfo.data;
      }
    },
    // 选中图片回调
    handleSelectionChange(imgList) {
      this.skuInfo.skuImageList = imgList;
    },
    // 设为默认按钮
    isDefault(index) {
      this.spuImageList.forEach((item) => {
        item.isDefault = 0;
      });
      this.spuImageList[index].isDefault = 1;
      this.skuInfo.skuDefaultImg = this.spuImageList[index].imgUrl;
    },
    // 收集数据
    async saveSkuInfo() {
      //整理图片数据
      this.skuInfo.skuImageList.forEach((item) => {
        item.spuImgId = item.id;
        delete item.id;
        delete item.spuId;
      });

      // 收集平台数据
      // skuAttrValueList: [
      //   {attrId: "106", valueId: "175"}]
      this.attrInfoList.forEach((item) => {
        if (item.attrIdAndValueId) {
          const [attrId, valueId] = item.attrIdAndValueId.split(":");
          this.skuInfo.skuAttrValueList.push({ attrId, valueId });
        }
      });
      console.log(this.skuInfo.skuAttrValueList);

      // 收集销售属性数据
      this.skuInfo.skuSaleAttrValueList = this.saleAttrList.reduce(
        (prev, item) => {
          if (item.attrIdAndValueId) {
            const [saleAttrId, saleAttrValueId] =
              item.attrIdAndValueId.split(":");
            prev.push({ saleAttrId, saleAttrValueId });
          }
          return prev;
        },
        []
      );
      console.log(this.skuInfo.skuSaleAttrValueList);

      let result = await this.$API.spu.reqSaveSkuInfo(this.skuInfo);
      if (result.code == 200) {
        this.$message({ type: "success", message: "保存成功" });
        this.$emit("changeScene", { scene: 0, flag: "" });
        Object.assign(this._data, this.$options.data());
      }
    },
  },
};
</script>

<style scoped>
</style>