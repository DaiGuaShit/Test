<template>
  <div>
    <el-form ref="form" label-width="80px">
      <el-form-item label="SPU名称">
        <el-input v-model="spu.spuName" placeholder="SPU名称"></el-input>
      </el-form-item>
      <el-form-item label="品牌">
        <el-select placeholder="请选择品牌" v-model="spu.tmId">
          <el-option
            :label="trademark.tmName"
            :value="trademark.id"
            v-for="trademark in trademarkList"
            :key="trademark.id"
            >{{ trademark.tmName }}</el-option
          >
        </el-select>
      </el-form-item>
      <el-form-item label="SPU描述">
        <el-input
          placeholder="SPU描述"
          type="textarea"
          rows="4"
          v-model="spu.description"
        ></el-input>
      </el-form-item>
      <el-form-item label="SPU图片">
        <!-- -->
        <el-upload
          action="/dev-api/admin/product/fileUpload"
          list-type="picture-card"
          :file-list="spuImageList"
          :on-preview="handlePictureCardPreview"
          :on-remove="handleRemove"
          :on-success="handleSuccess"
        >
          <i class="el-icon-plus"></i>
        </el-upload>
        <el-dialog :visible.sync="dialogVisible">
          <img width="100%" :src="dialogImageUrl" alt="" />
        </el-dialog>
      </el-form-item>
      <el-form-item label="销售属性">
        <el-select
          :placeholder="`还有${unSelectedSaleAttr.length}条未选择`"
          v-model="attrIdAndName"
        >
          <el-option
            :label="saleAttr.name"
            :value="`${saleAttr.id}:${saleAttr.name}`"
            v-for="saleAttr in unSelectedSaleAttr"
            :key="saleAttr.id"
          ></el-option>
        </el-select>
        <el-button
          type="primary"
          icon="el-icon-plus"
          :disabled="!attrIdAndName"
          @click="addAttr"
          >添加销售属性</el-button
        >
        <el-table style="width: 100%" border :data="spu.spuSaleAttrList">
          <el-table-column type="index" label="序号" width="80" align="center">
          </el-table-column>
          <el-table-column prop="saleAttrName" label="属性名" width="120">
          </el-table-column>
          <el-table-column prop="prop" label="属性值名称列表" width="600">
            <template slot-scope="{ row, $index }">
              <el-tag
                :key="tag.id"
                v-for="tag in row.spuSaleAttrValueList"
                closable
                :disable-transitions="false"
                @close="row.spuSaleAttrValueList.splice($index, 1)"
              >
                {{ tag.saleAttrValueName }}
              </el-tag>
              <el-input
                class="input-new-tag"
                v-if="row.inputVisible"
                v-model="row.inputValue"
                ref="saveTagInput"
                size="small"
                @keyup.enter.native="handleInputConfirm(row)"
                @blur="handleInputConfirm(row)"
              >
              </el-input>
              <el-button
                v-else
                class="button-new-tag"
                size="small"
                @click="addAttrValue(row)"
                >添加</el-button
              >
            </template>
          </el-table-column>
          <el-table-column prop="prop" label="操作" width="width">
            <template slot-scope="{ row, $index }">
              <el-popconfirm
                :title="`确定删除${row.saleAttrName}属性吗？`"
                @onConfirm="deleteAttr($index)"
              >
                <el-button
                  type="danger"
                  icon="el-icon-delete"
                  size="mini"
                  slot="reference"
                ></el-button>
              </el-popconfirm>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="saveOrUpdateSpu">保存</el-button>
        <el-button @click="cancel">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  name: "",
  data() {
    return {
      dialogVisible: false,
      dialogImageUrl: "",

      trademarkList: [], //所有品牌
      baseSaleAttrList: [], //所有销售属性
      spuImageList: [], //spu下的图片 带name和url

      spu: {
        category3Id: 0,
        tmId: "", //品牌id
        description: "",
        spuName: "",
        spuImageList: [], //spu下的图片 不带name和url
        spuSaleAttrList: [], //spu下的销售属性
      },

      attrIdAndName: "", //临时保存选中的销售属性
    };
  },
  methods: {
    // 图片预览回调
    handlePictureCardPreview(file) {
      this.dialogVisible = true;
      this.dialogImageUrl =
        (file.response && file.response.data) || file.imgUrl;
    },
    // 图片删除回调
    handleRemove(file, fileList) {
      this.spuImageList = fileList;
    },
    // 图片上传成功回调
    handleSuccess(response, file, fileList) {
      this.spuImageList = fileList;
    },
    // 取消按钮
    cancel() {
      this.$emit("changeScene", { scene: 0, flag: "" });
      Object.assign(this._data, this.$options.data());
    },
    // 修改spu时发请求
    async editData(spu) {
      //获取SPU信息
      let resultSpuDetail = await this.$API.spu.reqSpuDetail(spu.id);
      if (resultSpuDetail.code == 200) {
        this.spu = resultSpuDetail.data;
      }

      //获取品牌的信息
      let resultTrademark = await this.$API.spu.reqTrademarkList();
      if (resultTrademark.code == 200) {
        this.trademarkList = resultTrademark.data;
      }

      //获取SPU图片的接口
      let resultSpuImage = await this.$API.spu.reqSpuImageList(spu.id);
      if (resultSpuImage.code == 200) {
        this.spuImageList = resultSpuImage.data;
        this.spuImageList.forEach((item) => {
          item.name = item.imgName;
          item.url = item.imgUrl;
        });
      }

      //获取平台全部销售属性
      let resultBaseSaleAttr = await this.$API.spu.reqBaseSaleAttrList();
      if (resultBaseSaleAttr.code == 200) {
        this.baseSaleAttrList = resultBaseSaleAttr.data;
      }
    },
    // 新增spu时发请求
    async addData(category3Id) {
      this.spu.category3Id = category3Id;

      //获取品牌的信息
      let resultTrademark = await this.$API.spu.reqTrademarkList();
      if (resultTrademark.code == 200) {
        this.trademarkList = resultTrademark.data;
      }

      //获取平台全部销售属性
      let resultBaseSaleAttr = await this.$API.spu.reqBaseSaleAttrList();
      if (resultBaseSaleAttr.code == 200) {
        this.baseSaleAttrList = resultBaseSaleAttr.data;
      }
    },
    // 点击添加属性按钮
    addAttr() {
      const [baseSaleAttrId, saleAttrName] = this.attrIdAndName.split(":");
      this.spu.spuSaleAttrList.push({
        baseSaleAttrId,
        saleAttrName,
        spuSaleAttrValueList: [],
      });
      this.attrIdAndName = "";
    },
    // 点击添加属性值按钮
    addAttrValue(row) {
      // inputVisible控制tag的input和button切换
      this.$set(row, "inputVisible", true);
      this.$set(row, "inputValue", "");
    },
    // 添加属性值失去焦点
    handleInputConfirm(row) {
      // console.log(row);
      // 判断不能为空
      if (row.inputValue.trim() == "") {
        this.$message({ type: "info", message: "属性值不能为空" });
        return;
      }

      let isRepeat = row.spuSaleAttrValueList.some((item) => {
        return item.saleAttrValueName == row.inputValue;
      });
      if (isRepeat) {
        this.$message({ type: "info", message: "属性值不能重复" });
        return;
      }

      row.spuSaleAttrValueList.push({
        baseSaleAttrId: row.baseSaleAttrId,
        saleAttrValueName: row.inputValue,
      });
      row.inputVisible = false;
    },
    // 删除属性
    deleteAttr(index) {
      this.spu.spuSaleAttrList.splice(index, 1);
    },
    // 添加/修改SPU
    async saveOrUpdateSpu() {
      this.spu.spuImageList = this.spuImageList.map((item) => {
        return {
          imgName: item.name,
          imgUrl: (item.response && item.response.data) || item.url,
        };
      });

      let result = await this.$API.spu.saveOrUpdateSpuInfo(this.spu);
      if (result.code == 200) {
        this.$message({ type: "success", message: "保存成功" });
        if (this.spu.id) {
          this.$emit("changeScene", { scene: 0, flag: "update" });
        } else {
          this.$emit("changeScene", { scene: 0, flag: "add" });
        }
      }
      // 清除数据
      Object.assign(this._data, this.$options.data());
    },
  },

  computed: {
    unSelectedSaleAttr() {
      let unSelectedSaleAttr = this.baseSaleAttrList.filter((allItem) => {
        return this.spu.spuSaleAttrList.every((item) => {
          return allItem.name !== item.saleAttrName;
        });
      });
      return unSelectedSaleAttr;
    },
  },
};
</script>

<style>
.el-tag + .el-tag {
  margin-left: 10px;
}
.button-new-tag {
  margin-left: 10px;
  height: 32px;
  line-height: 30px;
  padding-top: 0;
  padding-bottom: 0;
}
.input-new-tag {
  width: 90px;
  margin-left: 10px;
  vertical-align: bottom;
}
</style>