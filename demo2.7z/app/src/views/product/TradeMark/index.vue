<template>
  <div>
    <el-button
      type="primary"
      icon="el-icon-plus"
      style="margin: 10px 0px"
      @click="addTrademark"
    >
      添加
    </el-button>
    <el-table :data="records" style="width: 100%" border>
      <el-table-column type="index" label="序号" width="80" align="center">
      </el-table-column>
      <el-table-column prop="tmName" label="品牌名称" width="width">
      </el-table-column>
      <el-table-column label="品牌LOGO" width="width">
        <template slot-scope="{ row, $index }">
          <img :src="row.logoUrl" style="width: 100px; height: 100px" />
        </template>
      </el-table-column>
      <el-table-column label="操作" width="width">
        <template slot-scope="{ row, $index }">
          <el-button
            type="warning"
            size="mini"
            icon="el-icon-edit"
            @click="editTrademark(row)"
          >
            修改</el-button
          >
          <!-- @click="deleteTrademark(row)" -->
          <el-button
            type="danger"
            size="mini"
            icon="el-icon-delete"
            @click="deleteTrademark(row)"
          >
            刪除</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页器 -->
    <el-pagination
      :current-page="pageNum"
      :page-sizes="[3, 5, 10]"
      :page-size="pageSize"
      layout="prev, pager, next, jumper, ->, sizes, total"
      :total="totalCount"
      style="margin: 20px; text-align: center"
      @current-change="getTrademarkList"
      @size-change="handleSizeChange"
    >
    </el-pagination>
    <!-- 添加/修改品牌对话框 -->
    <el-dialog
      :title="tmForm.id ? '修改品牌' : '添加品牌'"
      :visible.sync="dialogFormVisible"
    >
      <el-form style="width: 80%" :model="tmForm" :rules="rules" ref="ruleForm">
        <el-form-item label="品牌名称" label-width="100px" prop="tmName">
          <el-input autocomplete="off" v-model="tmForm.tmName"></el-input>
        </el-form-item>
        <el-form-item label="品牌LOGO" label-width="100px" prop="logoUrl">
          <el-upload
            class="avatar-uploader"
            action="/dev-api/admin/product/fileUpload"
            :show-file-list="false"
            :on-success="handleAvatarSuccess"
            :before-upload="beforeAvatarUpload"
          >
            <img v-if="tmForm.logoUrl" :src="tmForm.logoUrl" class="avatar" />
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            <div slot="tip" class="el-upload__tip">
              只能上传jpg/png文件，且不超过500kb
            </div>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOrEditTradeMark">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "",
  data() {
    var validateTmName = (rule, value, callback) => {
      if (value.length < 2 || value.length > 10) {
        callback(new Error("长度在 2 到 10 个字符"));
      } else {
        callback();
      }
    };
    return {
      records: [],
      pageNum: 1,
      pageSize: 3,
      totalCount: 0,
      dialogFormVisible: false,
      // imageUrl: "",
      // 收集品牌信息
      tmForm: { tmName: "", logoUrl: "" },
      // 验证规则
      rules: {
        tmName: [
          { required: true, message: "请输入品牌名称", trigger: "blur" },
          // { min: 2,max: 10,message: "长度在 2 到 10 个字符",trigger: "change"},
          { validator: validateTmName, trigger: "change" },
        ],
        logoUrl: [{ required: true, message: "请选择品牌图片" }],
      },
    };
  },
  mounted() {
    this.getTrademarkList();
  },
  methods: {
    // 获取品牌列表
    async getTrademarkList(page = 1) {
      this.pageNum = page;
      const { pageNum, pageSize } = this;
      let result = await this.$API.trademark.reqTradeMarkList(
        pageNum,
        pageSize
      );
      if (result.code == 200) {
        this.records = result.data.records;
        this.totalCount = result.data.total;
      }
    },
    // 修改分页器页码
    // handleCurrentChange(page) {
    //   this.pageNum = page;
    //   this.getTrademarkList();
    // },
    // 修改分页器每页条数
    handleSizeChange(size) {
      this.pageSize = size;
      this.getTrademarkList();
    },
    // 添加品牌按钮
    addTrademark() {
      this.dialogFormVisible = true;
      this.tmForm = { tmName: "", logoUrl: "" };
    },
    // 修改品牌按钮
    editTrademark(row) {
      this.dialogFormVisible = true;
      this.tmForm = { ...row };
    },
    // 删除品牌按钮
    deleteTrademark(row) {
      // console.log(row);
      this.$confirm(`是否确认删除${row.tmName}信息?`, "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(async () => {
          let result = await this.$API.trademark.reqDeleteTradeMark(row.id);
          if (result.code == 200) {
            this.$message({
              type: "success",
              message: "删除成功!",
            });
            this.getTrademarkList(
              (this.records.length = 1 ? this.pageNum - 1 : this.pageNum)
            );
          }
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },
    // 	文件上传成功
    handleAvatarSuccess(res, file) {
      this.tmForm.logoUrl = res.data;
    },
    // 上传文件之前的钩子，参数为上传的文件，若返回 false 或者返回 Promise 且被 reject，则停止上传。
    beforeAvatarUpload(file) {
      const isJPG = file.type === "image/jpeg";
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error("上传头像图片只能是 JPG 格式!");
      }
      if (!isLt2M) {
        this.$message.error("上传头像图片大小不能超过 2MB!");
      }
      return isJPG && isLt2M;
    },
    // 对话框确定按钮 添加/修改品牌
    addOrEditTradeMark() {
      this.$refs.ruleForm.validate(async (success) => {
        if (success) {
          let result = await this.$API.trademark.reqAddOrEditTradeMark(
            this.tmForm
          );
          if (result.code == 200) {
            this.dialogFormVisible = false;
            this.$message({
              type: "success",
              message: this.tmForm.id ? "修改成功" : "新增成功",
            });
            this.getTrademarkList(this.tmForm.id ? this.tmForm.id : 1);
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
  },
};
</script>

<style>
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
</style>