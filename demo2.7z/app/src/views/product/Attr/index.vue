<template>
  <div>
    <el-card>
      <CategorySelect
        :getCategoryId="getCategoryId"
        :showTable="showTable"
      ></CategorySelect>
    </el-card>
    <el-card style="margin-top: 20px">
      <div v-show="showTable">
        <el-button
          type="primary"
          icon="el-icon-plus"
          @click="addAttr"
          :disabled="!categoryIdList.category3Id"
          >添加属性</el-button
        >
        <el-table :data="attrInfoList" style="width: 100%" border>
          <el-table-column type="index" label="序号" width="80">
          </el-table-column>
          <el-table-column prop="attrName" label="属性名称" width="200">
          </el-table-column>
          <el-table-column label="属性值列表" width="800">
            <template slot-scope="{ row, $index }">
              <el-tag
                type="success"
                v-for="attrValue in row.attrValueList"
                :key="attrValue.id"
                style="margin: 0px 10px"
                >{{ attrValue.valueName }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="prop" label="操作" width="width">
            <template slot-scope="{ row, $index }">
              <el-button
                type="warning"
                icon="el-icon-edit"
                size="mini"
                @click="editAttr(row)"
              ></el-button>
              <el-button
                type="danger"
                icon="el-icon-delete"
                size="mini"
              ></el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div v-show="!showTable">
        <el-form ref="form" label-width="80px">
          <el-form-item label="属性名">
            <el-input
              placeholder="请输入属性名"
              style="width: 200px"
              v-model="attrInfo.attrName"
            ></el-input>
          </el-form-item>
        </el-form>
        <el-button
          type="primary"
          icon="el-icon-plus"
          @click="addAttrValue"
          :disabled="!attrInfo.attrName"
          >添加属性值</el-button
        >
        <el-button @click="showTable = true">取消</el-button>
        <el-table
          :data="attrInfo.attrValueList"
          style="width: 100%; margin: 20px 0"
          border
        >
          <el-table-column type="index" label="序号" width="80" align="center">
          </el-table-column>
          <el-table-column label="属性值名称" width="width">
            <template slot-scope="{ row, $index }">
              <el-input
                v-if="row.flag"
                v-model="row.valueName"
                placeholder="请输入属性值名称"
                size="mini"
                @blur="toSpan(row)"
                @keyup.native.enter="toSpan(row)"
                :ref="$index"
              ></el-input>
              <!-- display: block把span转换成块元素 让其可点击切换的地方大一点 -->
              <span
                v-else
                @click="toInput(row, $index)"
                style="display: block"
                >{{ row.valueName }}</span
              >
            </template>
          </el-table-column>
          <el-table-column label="操作" width="width">
            <template slot-scope="{ row, $index }">
              <el-popconfirm
                title="这是一段内容确定删除吗？"
                @onConfirm="deleteAttrValue($index)"
              >
                <el-button
                  type="danger"
                  icon="el-icon-delete"
                  size="mini"
                  slot="reference"
                ></el-button>
              </el-popconfirm>
            </template>
          </el-table-column>
        </el-table>
        <el-button
          type="primary"
          :disabled="attrInfo.attrValueList.length < 1"
          @click="saveAttrInfo"
          >保存</el-button
        >
        <el-button @click="showTable = true">取消</el-button>
      </div>
    </el-card>
  </div>
</template>

<script>
import cloneDeep from "lodash/cloneDeep";
export default {
  name: "",
  data() {
    return {
      categoryIdList: {},
      // 属性列表
      attrInfoList: [],
      // 控制页面切换
      showTable: true,
      // 收集新增/修改的属性
      attrInfo: {
        attrName: "", //属性名
        attrValueList: [
          //属性名中属性值，因为属性值可以是多个，因此需要的是数组
          {
            attrId: 0, //属性的id
            valueName: "", // 属性值
          },
        ],
        categoryId: 0, //category3Id
        categoryLevel: 3,
      },
    };
  },
  methods: {
    // 获取到三级id后 发请求获取平台属性
    async getCategoryId(categoryIdList) {
      this.categoryIdList = categoryIdList;
      const { category1Id, category2Id, category3Id } = categoryIdList;
      let result = await this.$API.attr.reqAttrInfoList(
        category1Id,
        category2Id,
        category3Id
      );
      if (result.code == 200) {
        this.attrInfoList = result.data;
      }
    },
    // 添加属性按钮
    addAttr() {
      this.showTable = false;
      this.attrInfo = {
        attrName: "",
        attrValueList: [],
        categoryId: 0,
        categoryLevel: 3,
      };
    },
    // 编辑属性按钮
    editAttr(row) {
      this.showTable = false;
      // console.log(row);
      this.attrInfo = cloneDeep(row);
      // 修改属性时 给它的属性值加上flag=false标签
      this.attrInfo.attrValueList.forEach((item) => {
        this.$set(item, "flag", false);
      });
    },
    // 添加属性值按钮
    addAttrValue() {
      this.attrInfo.attrValueList.push({
        attrId: this.attrInfo.id,
        valueName: "",
        flag: true, //用于控制span和input的切换
      });
      this.$nextTick(() => {
        this.$refs[this.attrInfo.attrValueList.length - 1].focus();
      });
    },
    // 从input切换为span
    toSpan(row) {
      if (row.valueName.trim() == "") {
        this.$message({ type: "info", message: "请输入不为空的数据" });
        return;
      }
      let isRepeat = this.attrInfo.attrValueList.some((item) => {
        if (item !== row) {
          return item.valueName == row.valueName;
        }
      });
      if (isRepeat) {
        this.$message({ type: "info", message: "请输入不重复的数据" });
        return;
      }
      row.flag = false;
    },
    // 从span切换为input
    toInput(row, index) {
      row.flag = true;
      this.$nextTick(() => {
        this.$refs[index].focus();
      });
    },
    // 保存按钮 发请求
    async saveAttrInfo() {
      this.attrInfo.categoryId = this.categoryIdList.category3Id;
      this.attrInfo.attrValueList = this.attrInfo.attrValueList.filter(
        (item) => {
          delete item.flag;
          return true;
        }
      );
      // console.log(this.attrInfo.attrValueList);
      let result = await this.$API.attr.reqSaveAttrInfo(this.attrInfo);
      if (result.code == 200) {
        this.$message({ type: "success", message: "保存成功" });
        this.getCategoryId(this.categoryIdList);
        this.showTable = true;
      }
    },
    // 删除按钮 发请求
    deleteAttrValue(index) {
      this.attrInfo.attrValueList.splice(index, 1);
    },
  },
};
</script>

<style scoped>
</style>